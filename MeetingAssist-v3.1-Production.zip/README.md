# Meeting Assist — Cheating Daddy Edition (v2.0.0)

A real-time interview & meeting assistant extension for Chrome (Manifest V3) combining live tab audio capture (AssemblyAI v3) with multimodal screen snapshots (NVIDIA Llama 3.2 90B Vision + Llama 3.1 70B Instruct).

## 🚀 Key Features

* **Multimodal Screen + Audio Context:** Automatically snapshots the active tab when questions finish or when you hit `Enter`, sending both the live transcript and screen image to **NVIDIA Llama 3.2 90B Vision Instruct**.
* **5 Dedicated Profiles:** Interview (Coding & System Design), Sales Call, Business Meeting, Presentation, Negotiation.
* **Resume / Role Context:** Paste your background/skills to customize the AI's generated answers and code.
* **Click-Through Stealth Mode (`Ctrl/Cmd + M`):** Passes mouse clicks directly through the overlay to LeetCode, Google Docs, or Zoom underneath.
* **Stealth Keyboard Controls:**
  * `Ctrl/Cmd + \`: Instantly hide or restore the overlay.
  * `Ctrl/Cmd + Arrow Keys`: Reposition the window by 40px increments without touching your mouse.
  * `Enter` in the quick bar: Solve whatever question or coding problem is currently on screen.

## 📁 Architecture & Subfolder Structure

```
meeting-assist-extension/
├── manifest.json              # Extension Manifest V3 configuration
├── README.md                  # Documentation
├── popup/                     # Settings menu & session launcher
│   ├── popup.html             # UI with profile selector, resume context & vision toggle
│   └── popup.js               # Storage management & capture initiation
├── background/                # Background service worker
│   └── background.js          # Tab audio stream capture, JPEG tab screenshot & message relay
├── offscreen/                 # Offscreen engine
│   ├── offscreen.html         # Invisible DOM container
│   ├── offscreen.js           # AssemblyAI v3 WebSocket + NVIDIA Llama 3.2 Vision / 3.1
│   └── pcm-worklet.js         # 16kHz PCM16 AudioWorklet with RMS silence gating
└── content/                   # Active tab stealth overlay
    └── content.js             # Draggable HUD, quick prompt bar & keyboard shortcut listeners
```

## 🛠️ Quick Installation

1. Open Chrome and go to `chrome://extensions/`.
2. Enable **Developer mode** (toggle in top-right corner).
3. Click **Load unpacked** and select:  
   `c:\Users\eyesi\OneDrive\Desktop\Ironclad AI\meeting-assist-extension`
4. Open your meeting, interview, or coding tab (e.g. Google Meet, Zoom, LeetCode, or YouTube).
5. Click the extension icon, enter your **AssemblyAI API key** (NVIDIA key is pre-filled), paste any resume context, and click **Start Session**.
