// =========================================================
// 1. POPUP SCRIPT (v3.1 Carbon & Amber HUD Settings Launcher)
// =========================================================

const RESTRICTED_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "https://chrome.google.com/webstore",
  "https://chromewebstore.google.com"
];

const DEFAULT_ASSEMBLY_KEY = "a0aa7138051b4e75a5f1d071df3ba264";
const DEFAULT_GEMINI_KEY = "AIzaSyAl2D2WJUKGoGr3kUKkDy4BbRQl6AfnNFQ";
const DEFAULT_NVIDIA_KEY = "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";

function isValidCapturableUrl(url) {
  if (!url || typeof url !== "string") return false;
  const trimmed = url.trim().toLowerCase();
  return !RESTRICTED_PREFIXES.some((prefix) => trimmed.startsWith(prefix.trim()));
}

function setStatus(message, type = "info") {
  const statusEl = document.getElementById("status");
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.className = type === "error" ? "error" : type === "ok" ? "ok" : "";
}

function setLiveState(isLive) {
  const badge = document.getElementById("stateBadge");
  const stateText = document.getElementById("stateText");
  if (badge) {
    if (isLive) {
      badge.classList.add("live");
    } else {
      badge.classList.remove("live");
    }
  }
  if (stateText) {
    stateText.textContent = isLive ? "LIVE" : "STANDBY";
  }
}

async function initPopup() {
  const assemblyInput = document.getElementById("assemblyKey");
  const nvidiaInput = document.getElementById("nvidiaKey") || document.getElementById("coachKey");
  const profileSelect = document.getElementById("profileSelect");
  const customContextInput = document.getElementById("customContext");
  const visionToggle = document.getElementById("visionToggle");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");

  const stored = await chrome.storage.local.get([
    "assemblyAiKey",
    "aiProvider",
    "geminiKey",
    "nvidiaKey",
    "coachKey",
    "selectedProfile",
    "customContext",
    "enableVision",
    "isCapturing"
  ]);

  if (assemblyInput) {
    assemblyInput.value = stored.assemblyAiKey || DEFAULT_ASSEMBLY_KEY;
  }

  if (nvidiaInput) {
    // Fill with stored NVIDIA key, or default NVIDIA key
    nvidiaInput.value = stored.nvidiaKey || stored.coachKey || DEFAULT_NVIDIA_KEY;
  }

  if (stored.selectedProfile && profileSelect) {
    profileSelect.value = stored.selectedProfile;
  }

  if (stored.customContext && customContextInput) {
    customContextInput.value = stored.customContext;
  }

  if (typeof stored.enableVision === "boolean" && visionToggle) {
    visionToggle.checked = stored.enableVision;
  }

  if (stored.isCapturing) {
    setLiveState(true);
  }

  if (startBtn) {
    startBtn.addEventListener("click", async () => {
      const assemblyAiKey = assemblyInput ? assemblyInput.value.trim() : DEFAULT_ASSEMBLY_KEY;
      const rawKey = nvidiaInput ? nvidiaInput.value.trim() : DEFAULT_NVIDIA_KEY;
      const profile = profileSelect ? profileSelect.value : "interview";
      const customContext = customContextInput ? customContextInput.value.trim() : "";
      const enableVision = visionToggle ? visionToggle.checked : false;

      if (!assemblyAiKey) {
        setStatus("Please enter your AssemblyAI API key.", "error");
        return;
      }

      // Sniff provider: if key starts with AIza -> Gemini, else NVIDIA
      let selectedProvider = "nvidia";
      let coachKey = rawKey;

      if (rawKey.startsWith("AIza")) {
        selectedProvider = "gemini";
      } else if (rawKey.startsWith("nvapi-")) {
        selectedProvider = "nvidia";
      } else {
        // Fallback default
        selectedProvider = stored.aiProvider || "gemini";
        coachKey = selectedProvider === "gemini" ? DEFAULT_GEMINI_KEY : DEFAULT_NVIDIA_KEY;
      }

      // Save settings
      await chrome.storage.local.set({
        assemblyAiKey,
        aiProvider: selectedProvider,
        nvidiaKey: rawKey,
        coachKey,
        selectedProfile: profile,
        customContext,
        enableVision
      });

      // Check current tab
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!activeTab || !isValidCapturableUrl(activeTab.url)) {
        setStatus("Cannot capture this tab. Open Meet, YouTube, or Zoom first.", "error");
        return;
      }

      setStatus("Deploying Carbon HUD & connecting audio...", "info");

      // Send to Background Service Worker
      chrome.runtime.sendMessage(
        {
          action: "Begin Capture",
          tabId: activeTab.id,
          assemblyAiKey,
          aiProvider: selectedProvider,
          coachKey,
          nvidiaKey: rawKey,
          profile,
          customContext,
          enableVision
        },
        (response) => {
          if (chrome.runtime.lastError) {
            setStatus(`Error: ${chrome.runtime.lastError.message}`, "error");
            return;
          }
          if (response && response.ok) {
            setLiveState(true);
            setStatus("Copilot HUD LIVE! Press Ctrl+M for ghost mode, Ctrl+\\ to hide.", "ok");
          } else {
            setStatus(response?.error || "Failed to launch HUD.", "error");
          }
        }
      );
    });
  }

  if (stopBtn) {
    stopBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "Stop Capture" }, (response) => {
        setLiveState(false);
        if (response && response.ok) {
          setStatus("Session stopped. HUD parked in standby.", "info");
        }
      });
    });
  }
}

if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", initPopup);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { isValidCapturableUrl, initPopup };
}
