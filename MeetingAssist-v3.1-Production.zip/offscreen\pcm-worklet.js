// =========================================================
// PCM16 AudioWorkletProcessor (Streams 16kHz PCM16 + Hangover Silence for VAD)
// =========================================================

class Pcm16ChunkProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.chunkSize = 4096; // 256ms at 16kHz
    this.buffer = new Float32Array(this.chunkSize);
    this.writeIndex = 0;
    this.rmsSilenceThreshold = 0.004;
    // Keep sending up to 8 silent chunks (~2 seconds) after speech stops
    // so AssemblyAI's server-side VAD detects pauses even when YouTube is paused
    this.silentHangoverLimit = 8;
    this.silentChunksSent = 0;
  }

  process(inputs) {
    const input = inputs[0];
    const channelData = input && input[0] ? input[0] : null;

    if (!channelData) {
      if (this.silentChunksSent < this.silentHangoverLimit) {
        for (let i = 0; i < 128; i++) {
          this.buffer[this.writeIndex++] = 0;
          if (this.writeIndex >= this.chunkSize) {
            this.flushChunk(this.buffer);
            this.writeIndex = 0;
          }
        }
      }
      return true;
    }

    for (let i = 0; i < channelData.length; i++) {
      this.buffer[this.writeIndex++] = channelData[i];

      if (this.writeIndex >= this.chunkSize) {
        this.flushChunk(this.buffer);
        this.writeIndex = 0;
      }
    }
    return true;
  }

  flushChunk(float32Samples) {
    let sumSquares = 0;
    for (let i = 0; i < float32Samples.length; i++) {
      sumSquares += float32Samples[i] * float32Samples[i];
    }
    const rms = Math.sqrt(sumSquares / float32Samples.length);
    const isSilent = rms < this.rmsSilenceThreshold;

    if (isSilent) {
      if (this.silentChunksSent >= this.silentHangoverLimit) {
        return;
      }
      this.silentChunksSent++;
    } else {
      this.silentChunksSent = 0;
    }

    const pcm16 = new Int16Array(float32Samples.length);
    for (let i = 0; i < float32Samples.length; i++) {
      const clamped = Math.max(-1, Math.min(1, float32Samples[i]));
      pcm16[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
    }

    this.port.postMessage(
      {
        type: "AUDIO_CHUNK",
        rms,
        isSilent,
        pcm16Buffer: pcm16.buffer
      },
      [pcm16.buffer]
    );
  }
}

if (typeof registerProcessor !== "undefined") {
  registerProcessor("pcm16-chunk-processor", Pcm16ChunkProcessor);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { Pcm16ChunkProcessor };
}
