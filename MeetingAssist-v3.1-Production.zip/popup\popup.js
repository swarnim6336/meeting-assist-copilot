// =========================================================
// 1. POPUP SCRIPT (Carbon & Amber Control Center Launcher)
// =========================================================

const RESTRICTED_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "https://chrome.google.com/webstore",
  "https://chromewebstore.google.com"
];

const DEFAULT_ASSEMBLY_KEY = "a0aa7138051b4e75a5f1d071df3ba264";
const DEFAULT_NVIDIA_KEY = "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";

function isValidCapturableUrl(url) {
  if (!url || typeof url !== "string") return false;
  const trimmed = url.trim().toLowerCase();
  return !RESTRICTED_PREFIXES.some((prefix) => trimmed.startsWith(prefix.trim()));
}

function setStatus(message, type = "info") {
  const statusEl = document.getElementById("status");
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.className = type === "error" ? "error" : type === "ok" ? "ok" : "";
}

function updateBadgeState(isLive) {
  const badge = document.getElementById("stateBadge");
  const text = document.getElementById("stateText");
  if (!badge) return;
  if (isLive) {
    badge.classList.add("live");
    if (text) text.textContent = "LIVE";
  } else {
    badge.classList.remove("live");
    if (text) text.textContent = "STANDBY";
  }
}

async function initPopup() {
  const assemblyInput = document.getElementById("assemblyKey");
  const nvidiaInput = document.getElementById("nvidiaKey");
  const profileSelect = document.getElementById("profileSelect");
  const customContextInput = document.getElementById("customContext");
  const visionToggle = document.getElementById("visionToggle");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");

  const stored = await chrome.storage.local.get([
    "assemblyAiKey",
    "nvidiaKey",
    "selectedProfile",
    "customContext",
    "enableVision",
    "isCapturing"
  ]);

  if (assemblyInput) {
    assemblyInput.value = stored.assemblyAiKey || DEFAULT_ASSEMBLY_KEY;
  }
  if (nvidiaInput) {
    nvidiaInput.value = stored.nvidiaKey || DEFAULT_NVIDIA_KEY;
  }
  if (stored.selectedProfile && profileSelect) {
    profileSelect.value = stored.selectedProfile;
  }
  if (stored.customContext && customContextInput) {
    customContextInput.value = stored.customContext;
  }
  if (typeof stored.enableVision === "boolean" && visionToggle) {
    visionToggle.checked = stored.enableVision;
  }
  updateBadgeState(Boolean(stored.isCapturing));

  if (startBtn) {
    startBtn.addEventListener("click", async () => {
      const assemblyAiKey = assemblyInput ? assemblyInput.value.trim() : "";
      const nvidiaKey = nvidiaInput ? nvidiaInput.value.trim() : "";
      const profile = profileSelect ? profileSelect.value : "interview";
      const customContext = customContextInput ? customContextInput.value.trim() : "";
      const enableVision = visionToggle ? visionToggle.checked : false;

      if (!assemblyAiKey || !nvidiaKey) {
        setStatus("Please enter both AssemblyAI and NVIDIA NIM keys.", "error");
        return;
      }

      await chrome.storage.local.set({
        assemblyAiKey,
        nvidiaKey,
        selectedProfile: profile,
        customContext,
        enableVision
      });

      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!activeTab || !isValidCapturableUrl(activeTab.url)) {
        setStatus("Switch to a YouTube, Google Meet, Zoom, or coding tab first.", "error");
        return;
      }

      setStatus("Initializing Copilot HUD & audio stream...", "info");

      chrome.runtime.sendMessage(
        {
          action: "Begin Capture",
          tabId: activeTab.id,
          assemblyAiKey,
          nvidiaKey,
          coachKey: nvidiaKey,
          profile,
          customContext,
          enableVision
        },
        (response) => {
          if (chrome.runtime.lastError) {
            setStatus(`Error: ${chrome.runtime.lastError.message}`, "error");
            return;
          }
          if (response && response.ok) {
            updateBadgeState(true);
            setStatus("Copilot HUD active on tab!", "ok");
          } else {
            setStatus(response?.error || "Failed to start capture.", "error");
          }
        }
      );
    });
  }

  if (stopBtn) {
    stopBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "Stop Capture" }, (response) => {
        updateBadgeState(false);
        if (response && response.ok) {
          setStatus("Copilot session stopped.", "info");
        }
      });
    });
  }
}

if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", initPopup);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { isValidCapturableUrl, initPopup };
}
