// =========================================================
// 1. POPUP SCRIPT (Cheating Daddy Settings & Session Launcher)
// =========================================================

const RESTRICTED_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "https://chrome.google.com/webstore",
  "https://chromewebstore.google.com"
];

const DEFAULT_ASSEMBLY_KEY = "a0aa7138051b4e75a5f1d071df3ba264";
const DEFAULT_GEMINI_KEY = "AIzaSyAl2D2WJUKGoGr3kUKkDy4BbRQl6AfnNFQ";
const DEFAULT_NVIDIA_KEY = "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";

function isValidCapturableUrl(url) {
  if (!url || typeof url !== "string") return false;
  const trimmed = url.trim().toLowerCase();
  return !RESTRICTED_PREFIXES.some((prefix) => trimmed.startsWith(prefix.trim()));
}

function setStatus(message, type = "info") {
  const statusEl = document.getElementById("status");
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.className = type === "error" ? "error" : type === "ok" ? "ok" : "";
}

async function initPopup() {
  const assemblyInput = document.getElementById("assemblyKey");
  const aiProviderSelect = document.getElementById("aiProvider");
  const coachInput = document.getElementById("coachKey");
  const coachKeyLabel = document.getElementById("coachKeyLabel");
  const profileSelect = document.getElementById("profileSelect");
  const customContextInput = document.getElementById("customContext");
  const visionToggle = document.getElementById("visionToggle");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const stateBadge = document.getElementById("stateBadge");

  const stored = await chrome.storage.local.get([
    "assemblyAiKey",
    "aiProvider",
    "geminiKey",
    "nvidiaKey",
    "coachKey",
    "selectedProfile",
    "customContext",
    "enableVision",
    "isCapturing"
  ]);

  // Set default AssemblyAI key
  assemblyInput.value = stored.assemblyAiKey || DEFAULT_ASSEMBLY_KEY;

  const provider = stored.aiProvider || "gemini";
  aiProviderSelect.value = provider;

  function updateProviderUI(p) {
    if (p === "gemini") {
      coachKeyLabel.textContent = "Gemini API Key";
      coachInput.placeholder = "AIzaSy...";
      coachInput.value = stored.geminiKey || DEFAULT_GEMINI_KEY;
    } else {
      coachKeyLabel.textContent = "NVIDIA NIM API Key";
      coachInput.placeholder = "nvapi-...";
      coachInput.value = stored.nvidiaKey || DEFAULT_NVIDIA_KEY;
    }
  }

  aiProviderSelect.addEventListener("change", () => {
    updateProviderUI(aiProviderSelect.value);
  });

  updateProviderUI(provider);

  if (stored.selectedProfile) profileSelect.value = stored.selectedProfile;
  if (stored.customContext && customContextInput) customContextInput.value = stored.customContext;
  if (typeof stored.enableVision === "boolean" && visionToggle) {
    visionToggle.checked = stored.enableVision;
  }

  if (stored.isCapturing) {
    stateBadge.textContent = "LIVE";
    stateBadge.style.background = "#16a34a";
  }

  startBtn.addEventListener("click", async () => {
    const assemblyAiKey = assemblyInput.value.trim();
    const selectedProvider = aiProviderSelect.value;
    const coachKey = coachInput.value.trim();
    const profile = profileSelect.value;
    const customContext = customContextInput ? customContextInput.value.trim() : "";
    const enableVision = visionToggle ? visionToggle.checked : true;

    if (!assemblyAiKey) {
      setStatus("Please enter your AssemblyAI API key for live speech transcription.", "error");
      return;
    }

    if (!coachKey) {
      setStatus("Please enter your AI Coach API key.", "error");
      return;
    }

    // 1. Save settings to Chrome Local Storage
    const toSave = {
      assemblyAiKey,
      aiProvider: selectedProvider,
      coachKey,
      selectedProfile: profile,
      customContext,
      enableVision
    };
    if (selectedProvider === "gemini") toSave.geminiKey = coachKey;
    else toSave.nvidiaKey = coachKey;

    await chrome.storage.local.set(toSave);

    // 2. Check if current website is valid (not a chrome:// page)
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!activeTab || !isValidCapturableUrl(activeTab.url)) {
      setStatus("Cannot capture this tab. Switch to Meet, Zoom, LeetCode, or YouTube.", "error");
      return;
    }

    setStatus("Launching stealth overlay & audio engine...", "info");

    // 3. Send message to Background Script -> "Begin Capture"
    chrome.runtime.sendMessage(
      {
        action: "Begin Capture",
        tabId: activeTab.id,
        assemblyAiKey,
        aiProvider: selectedProvider,
        coachKey,
        profile,
        customContext,
        enableVision
      },
      (response) => {
        if (chrome.runtime.lastError) {
          setStatus(`Error: ${chrome.runtime.lastError.message}`, "error");
          return;
        }
        if (response && response.ok) {
          stateBadge.textContent = "LIVE";
          stateBadge.style.background = "#16a34a";
          setStatus("Session active! Use Ctrl+M for click-through or Ctrl+\\ to hide.", "ok");
        } else {
          setStatus(response?.error || "Failed to start capture.", "error");
        }
      }
    );
  });

  stopBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "Stop Capture" }, (response) => {
      stateBadge.textContent = "IDLE";
      stateBadge.style.background = "#334155";
      if (response && response.ok) {
        setStatus("Session stopped.", "info");
      }
    });
  });
}

if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", initPopup);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { isValidCapturableUrl, initPopup };
}
