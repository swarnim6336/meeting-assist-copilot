// =========================================================
// PCM16 AudioWorkletProcessor — Low-Latency VAD Buffer
// =========================================================
// Uses 1024 sample chunks (~64ms at 16kHz) for near-instant
// transmission to AssemblyAI, with a 20-chunk hangover budget
// (~1.3s) so silence pauses are detected quickly by server VAD.

class Pcm16ChunkProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.chunkSize = 1024;             // ~64ms at 16kHz (low-latency streaming)
    this.buffer = new Float32Array(this.chunkSize);
    this.writeIndex = 0;
    this.rmsSilenceThreshold = 0.0035; // sensitive threshold
    this.silentHangoverLimit = 20;     // ~1.3s hangover budget before dropping frames
    this.silentChunksSent = 0;
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;
    const channelData = input[0];
    if (!channelData) return true;

    for (let i = 0; i < channelData.length; i++) {
      this.buffer[this.writeIndex++] = channelData[i];
      if (this.writeIndex >= this.chunkSize) {
        this.flushChunk(this.buffer);
        this.writeIndex = 0;
      }
    }
    return true;
  }

  flushChunk(float32Samples) {
    let sumSquares = 0;
    for (let i = 0; i < float32Samples.length; i++) {
      sumSquares += float32Samples[i] * float32Samples[i];
    }
    const rms = Math.sqrt(sumSquares / float32Samples.length);

    if (rms < this.rmsSilenceThreshold) {
      if (this.silentChunksSent >= this.silentHangoverLimit) {
        return; // Drop silent frames after hangover budget exhausted
      }
      this.silentChunksSent++;
    } else {
      this.silentChunksSent = 0;
    }

    const pcm16 = new Int16Array(float32Samples.length);
    for (let i = 0; i < float32Samples.length; i++) {
      const clamped = Math.max(-1, Math.min(1, float32Samples[i]));
      pcm16[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
    }

    this.port.postMessage(
      { type: "AUDIO_CHUNK", rms, pcm16Buffer: pcm16.buffer },
      [pcm16.buffer]
    );
  }
}

if (typeof registerProcessor !== "undefined") {
  registerProcessor("pcm16-chunk-processor", Pcm16ChunkProcessor);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { Pcm16ChunkProcessor };
}
