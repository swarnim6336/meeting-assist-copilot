// =========================================================
// 2. BACKGROUND SCRIPT (Service Worker: Audio + Screen Manager)
// =========================================================

let activeCaptureTabId = null;

async function recreateOffscreenDocument() {
  try {
    if (chrome.offscreen && chrome.offscreen.closeDocument) {
      await chrome.offscreen.closeDocument();
    }
  } catch (_) {}

  await chrome.offscreen.createDocument({
    url: "offscreen/offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Capture tab audio stream and process real-time speech-to-text for Meeting Assist"
  });
}

async function captureActiveTabScreenshot() {
  if (!chrome.tabs || !chrome.tabs.captureVisibleTab) return null;
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(null, {
      format: "jpeg",
      quality: 40
    });
    return dataUrl || null;
  } catch (_) {
    return null;
  }
}

async function handleBeginCapture(message) {
  const {
    tabId,
    assemblyAiKey,
    nvidiaKey,
    coachKey,
    profile,
    customContext = "",
    enableVision = false
  } = message;
  activeCaptureTabId = tabId;

  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content/content.js"]
  });

  try {
    await chrome.tabs.sendMessage(tabId, { action: "restore_overlay" });
  } catch (_) {}

  await recreateOffscreenDocument();

  const streamId = await chrome.tabCapture.getMediaStreamId({
    targetTabId: tabId
  });

  if (!streamId) {
    throw new Error("Unable to obtain tabCapture MediaStream ID.");
  }

  const engineResponse = await chrome.runtime.sendMessage({
    target: "offscreen",
    action: "Start Engine",
    streamId,
    assemblyAiKey,
    nvidiaKey: nvidiaKey || coachKey,
    coachKey: coachKey || nvidiaKey,
    profile,
    customContext,
    enableVision,
    tabId
  });

  await chrome.storage.local.set({ isCapturing: true, activeCaptureTabId: tabId });
  return engineResponse || { ok: true };
}

async function handleStopCapture() {
  try {
    await chrome.runtime.sendMessage({
      target: "offscreen",
      action: "Stop Engine"
    });
    if (chrome.offscreen && chrome.offscreen.closeDocument) {
      await chrome.offscreen.closeDocument();
    }
  } catch (_) {}
  if (activeCaptureTabId) {
    try {
      await chrome.tabs.sendMessage(activeCaptureTabId, { action: "hide_overlay" });
    } catch (_) {}
  }
  await chrome.storage.local.set({ isCapturing: false, activeCaptureTabId: null });
  activeCaptureTabId = null;
  return { ok: true };
}

async function relayToContentScript(payload) {
  let targetTabId = payload.tabId || activeCaptureTabId;
  if (!targetTabId) {
    const stored = await chrome.storage.local.get(["activeCaptureTabId"]);
    targetTabId = stored.activeCaptureTabId;
  }
  if (!targetTabId) return { ok: false, error: "No active capture tab ID" };

  try {
    await chrome.tabs.sendMessage(targetTabId, payload);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.action) return false;

  if (message.action === "Begin Capture") {
    handleBeginCapture(message)
      .then((res) => sendResponse({ ok: true, ...res }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Stop Capture") {
    handleStopCapture()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Capture Screenshot") {
    captureActiveTabScreenshot()
      .then((screenshotDataUrl) => sendResponse({ ok: true, screenshotDataUrl }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Manual Prompt") {
    const shouldSnap = Boolean(message.includeScreen);
    const snapPromise = shouldSnap ? captureActiveTabScreenshot() : Promise.resolve(null);
    snapPromise
      .then((screenshotDataUrl) =>
        chrome.runtime.sendMessage({
          target: "offscreen",
          action: "Manual Coach Trigger",
          promptText: message.promptText || "",
          screenshotDataUrl
        })
      )
      .then((res) => sendResponse(res || { ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (
    message.target === "content" &&
    (message.action === "Update Live Transcript" ||
      message.action === "Update AI Coach" ||
      message.action === "Stream AI Coach" ||
      message.action === "Update Engine Status")
  ) {
    relayToContentScript(message)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  return false;
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    recreateOffscreenDocument,
    captureActiveTabScreenshot,
    handleBeginCapture,
    handleStopCapture,
    relayToContentScript
  };
}
