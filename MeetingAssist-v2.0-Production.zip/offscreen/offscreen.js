// =========================================================
// 3. OFFSCREEN SCRIPT (Ultra-Fast Audio + AI Engine)
// =========================================================

const LOG = (...args) => console.log("[OFFSCREEN]", ...args);
const ERR = (...args) => console.error("[OFFSCREEN ERROR]", ...args);

// Updated candidate list — llama-3.1-70b removed (EOL/410)
const TEXT_MODEL_CANDIDATES = [
  "meta/llama-3.3-70b-instruct",
  "meta/llama-3.1-8b-instruct",
  "meta/llama-4-maverick-17b-128e-instruct",
  "meta/llama-4-scout-17b-16e-instruct"
];

const VISION_MODEL_CANDIDATES = [
  "meta/llama-4-maverick-17b-128e-instruct",
  "meta/llama-4-scout-17b-16e-instruct",
  "meta/llama-3.2-90b-vision-instruct",
  "meta/llama-3.2-11b-vision-instruct"
];

let cachedWorkingTextModel = null;
let cachedWorkingVisionModel = null;

// Ultra-concise prompts: 1-2 punchy bullets, under 30 words so tokens stream immediately!
const PROFILE_PROMPTS = {
  interview:
    "You are a real-time Interview Copilot. Give 1-2 ultra-crisp bullet points (under 30 words total) the candidate can say out loud immediately. If a coding problem is visible, give the optimal approach, complexity, and 1-line key snippet.",
  sales:
    "You are an elite Sales Copilot. Give 1-2 ultra-concise talking points (under 25 words total) to handle objections or advance the close.",
  meeting:
    "You are an Executive Meeting Copilot. Provide 1 sharp talking point or clarifying question (under 25 words total) to drive alignment.",
  presentation:
    "You are a Live Presentation Defense Copilot. Provide a crisp, confident, data-backed response (under 25 words total).",
  negotiation:
    "You are a tactical Negotiation Copilot. Give 1-2 sharp leverage bullets (under 25 words total) on anchoring or concessions."
};

const SAMPLE_RATE = 16000;

let mediaStream = null;
let audioContext = null;
let workletNode = null;
let assemblySocket = null;
let recentTurns = [];
let currentSession = {
  assemblyAiKey: null,
  nvidiaKey: null,
  coachKey: null,
  aiProvider: "gemini",
  geminiKey: null,
  profile: "interview",
  customContext: "",
  enableVision: true,
  tabId: null
};

// ---- In-flight dedup guard & pending queue ----
let isCoachInFlight = false;
let pendingCoachText = null;

// ---- Fast partial-trigger rate limiting ----
let lastPartialCoachTimestamp = 0;
const PARTIAL_COACH_INTERVAL_MS = 1400; // Fast 1.4s gap for continuous speech

// ---- Low-latency silence debounce (triggers on 350ms speaker pause) ----
let silenceDebounceTimer = null;
let latestTranscriptText = "";

// =========================================================
// Utilities
// =========================================================

function sendToContentOverlay(action, data) {
  const payload = {
    target: "content",
    action,
    tabId: currentSession.tabId,
    ...data
  };
  chrome.runtime.sendMessage(payload, () => {
    if (chrome.runtime.lastError) {
      ERR("sendToContentOverlay failed for", action, ":", chrome.runtime.lastError.message);
    }
  });
}

async function fetchAssemblyAiTempToken(assemblyAiKey) {
  LOG("Fetching AssemblyAI temp token...");
  const response = await fetch("https://streaming.assemblyai.com/v3/token?expires_in_seconds=60", {
    method: "GET",
    headers: { Authorization: assemblyAiKey }
  });
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`AssemblyAI token error (${response.status}): ${errText}`);
  }
  const data = await response.json();
  if (!data.token) throw new Error("AssemblyAI token response missing 'token' field.");
  LOG("AssemblyAI temp token obtained.");
  return data.token;
}

// Check if a sentence actually needs screen vision context
function needsVisionContext(text) {
  if (!text) return false;
  return /\b(screen|code|diagram|slide|problem|leetcode|image|graph|chart|figure|error|stack|trace|snippet|tab)\b/i.test(text);
}

async function requestTabScreenshotIfEnabled(sessionConfig) {
  if (!sessionConfig.enableVision) return null;
  try {
    const res = await chrome.runtime.sendMessage({ action: "Capture Screenshot" });
    return res && res.ok ? res.screenshotDataUrl : null;
  } catch (_) {
    return null;
  }
}

async function discoverLiveNvidiaModel(nvidiaKey) {
  if (!nvidiaKey) return null;
  try {
    const res = await fetch("https://integrate.api.nvidia.com/v1/models", {
      method: "GET",
      headers: { Authorization: `Bearer ${nvidiaKey}`, Accept: "application/json" }
    });
    if (!res.ok) return null;
    const data = await res.json();
    const modelIds = (data?.data || []).map((m) => (typeof m === "string" ? m : m.id)).filter(Boolean);
    for (const pat of [/llama-3\.3-70b/i, /llama-4/i, /nemotron/i, /llama-3/i]) {
      const match = modelIds.find((id) => pat.test(id));
      if (match) return match;
    }
    return modelIds[0] || null;
  } catch (_) {
    return null;
  }
}

// =========================================================
// Gemini 2.5 Flash Real-Time SSE Token Streaming
// (Disables thinking tokens & streams chunks in ~400ms)
// =========================================================

async function callGeminiStream(systemPrompt, userTextPrompt, screenshotDataUrl, apiKey, onChunk) {
  LOG("Calling Gemini 2.5 Flash STREAM | hasScreenshot:", Boolean(screenshotDataUrl));
  const parts = [{ text: `${systemPrompt}\n\n${userTextPrompt}` }];
  if (screenshotDataUrl) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: screenshotDataUrl.replace(/^data:image\/[a-z]+;base64,/, "")
      }
    });
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse&key=${apiKey}`;

  const payload = {
    contents: [{ parts }],
    generationConfig: {
      maxOutputTokens: 85,          // Keep it short so total time is minimal
      temperature: 0.2,
      thinkingConfig: {
        thinkingBudget: 0           // STOP model from spending 1-2s on thinking tokens!
      }
    }
  };

  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } catch (netErr) {
    throw new Error(`Gemini network error: ${netErr.message}`);
  }

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Gemini HTTP ${response.status}: ${err}`);
  }

  if (!response.body || !response.body.getReader) {
    const json = await response.json();
    return json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "Directly address the question.";
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let fullText = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop(); // keep partial line for next iteration

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const jsonStr = trimmed.slice(5).trim();
      if (!jsonStr || jsonStr === "[DONE]") continue;

      try {
        const parsed = JSON.parse(jsonStr);
        const pList = parsed?.candidates?.[0]?.content?.parts || [];
        for (const p of pList) {
          if (p.text && !p.thought) {
            fullText += p.text;
            if (onChunk) onChunk(fullText);
          }
        }
      } catch (_) {}
    }
  }

  return fullText.trim() || "Directly address the question.";
}

// =========================================================
// NVIDIA API with failover (Non-streaming fallback)
// =========================================================

async function callNvidiaWithFailover(systemPrompt, userTextPrompt, screenshotDataUrl, nvidiaKey) {
  const isVision = Boolean(screenshotDataUrl);
  const modelQueue = isVision
    ? (cachedWorkingVisionModel
        ? [cachedWorkingVisionModel, ...VISION_MODEL_CANDIDATES.filter((m) => m !== cachedWorkingVisionModel)]
        : [...VISION_MODEL_CANDIDATES])
    : (cachedWorkingTextModel
        ? [cachedWorkingTextModel, ...TEXT_MODEL_CANDIDATES.filter((m) => m !== cachedWorkingTextModel)]
        : [...TEXT_MODEL_CANDIDATES]);

  let advice = null;
  let modelUsed = null;
  let lastError = null;

  for (const model of modelQueue) {
    LOG("Trying NVIDIA model:", model);
    const userContent = isVision
      ? [{ type: "text", text: userTextPrompt }, { type: "image_url", image_url: { url: screenshotDataUrl } }]
      : userTextPrompt;

    try {
      const response = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${nvidiaKey}`
        },
        body: JSON.stringify({
          model,
          messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userContent }],
          temperature: 0.2, top_p: 0.7, max_tokens: 120, stream: false
        })
      });

      if (response.status === 401 || response.status === 403) {
        const errBody = await response.text();
        throw new Error(`NVIDIA API Auth Error (${response.status}): ${errBody}`);
      }
      if (!response.ok) {
        ERR(`NVIDIA model ${model} → HTTP ${response.status}`);
        lastError = new Error(`NVIDIA HTTP ${response.status}`);
        continue;
      }
      const result = await response.json();
      advice = result?.choices?.[0]?.message?.content?.trim();
      if (advice) {
        modelUsed = model;
        if (isVision) cachedWorkingVisionModel = model;
        else cachedWorkingTextModel = model;
        break;
      }
    } catch (err) {
      if (err.message.includes("NVIDIA API Auth Error")) throw err;
      lastError = err;
    }
  }

  if (!advice) throw lastError || new Error("All NVIDIA models failed.");
  return { advice, modelUsed };
}

// =========================================================
// AI Coach — Real-time stream with fast dispatch
// =========================================================

async function triggerAiCoach(inputSentence, sessionConfig = currentSession, explicitScreenshot = null) {
  const cleanSentence = (inputSentence || "").trim();
  if (!cleanSentence) return;

  // In-flight guard: don't pile up simultaneous requests
  if (isCoachInFlight) {
    LOG("Coach in-flight — queuing latest text:", cleanSentence.slice(0, 50));
    pendingCoachText = cleanSentence;
    return;
  }

  isCoachInFlight = true;
  pendingCoachText = null;

  // Immediate visual feedback on overlay
  sendToContentOverlay("Update AI Coach", {
    advice: `⚡ Analyzing...`,
    isPending: true
  });

  const aiProvider = sessionConfig.aiProvider || "gemini";
  const geminiKey = sessionConfig.geminiKey ||
    (sessionConfig.coachKey?.startsWith("AIza") ? sessionConfig.coachKey : null);
  const nvidiaKey = sessionConfig.nvidiaKey || sessionConfig.coachKey;
  const profile = sessionConfig.profile || "interview";
  const customContext = sessionConfig.customContext || "";

  const basePrompt = PROFILE_PROMPTS[profile] || PROFILE_PROMPTS.interview;
  const systemPrompt = customContext
    ? `${basePrompt}\nContext: ${customContext}`
    : basePrompt;

  recentTurns.push(cleanSentence);
  if (recentTurns.length > 5) recentTurns.shift();

  const userTextPrompt =
    `Recent transcript:\n${recentTurns.join("\n")}` +
    `\n\nLatest question: "${cleanSentence}"` +
    `\nGive 1-2 bullet points to speak immediately:`;

  // SPEED OPTIMIZATION: Only take screenshot if explicitly triggered OR sentence has visual cues.
  // This eliminates 1.5 - 2.5 seconds of screenshot capture/upload delay on pure speech!
  let screenshotDataUrl = explicitScreenshot;
  if (!screenshotDataUrl && sessionConfig.enableVision && needsVisionContext(cleanSentence)) {
    LOG("Visual keyword detected in speech — taking tab screenshot...");
    screenshotDataUrl = await requestTabScreenshotIfEnabled(sessionConfig);
  }

  try {
    let advice, modelUsed;
    if (aiProvider === "gemini" && geminiKey) {
      // STREAMING: Tokens arrive in real-time (~350ms first token!)
      advice = await callGeminiStream(
        systemPrompt,
        userTextPrompt,
        screenshotDataUrl,
        geminiKey,
        (streamedSoFar) => {
          sendToContentOverlay("Stream AI Coach", { text: streamedSoFar });
        }
      );
      modelUsed = "Gemini 2.5 Flash (Stream)";
    } else if (nvidiaKey) {
      const res = await callNvidiaWithFailover(systemPrompt, userTextPrompt, screenshotDataUrl, nvidiaKey);
      advice = res.advice;
      modelUsed = res.modelUsed;
    } else {
      throw new Error("No AI API key — set Gemini or NVIDIA key in popup.");
    }

    LOG("AI complete | model:", modelUsed, "| text:", advice.slice(0, 60));
    sendToContentOverlay("Update AI Coach", { advice, profile, modelUsed, sourceSentence: cleanSentence });
  } catch (err) {
    ERR("triggerAiCoach failed:", err.message);
    sendToContentOverlay("Update AI Coach", {
      advice: `[Coach Error] ${err.message}`,
      profile,
      isError: true
    });
  } finally {
    isCoachInFlight = false;
    // Drain queued transcript if any arrived while processing
    if (pendingCoachText) {
      const queued = pendingCoachText;
      pendingCoachText = null;
      LOG("Draining queued text:", queued.slice(0, 50));
      triggerAiCoach(queued, sessionConfig, null);
    }
  }
}

// =========================================================
// Fast Silence Debounce (350ms pause triggers AI)
// =========================================================

function resetSilenceDebounce(text) {
  if (silenceDebounceTimer) {
    clearTimeout(silenceDebounceTimer);
    silenceDebounceTimer = null;
  }
  if (!text || text.split(/\s+/).length < 4) return;
  // 350ms pause is enough to detect end of statement without awkward delay
  silenceDebounceTimer = setTimeout(() => {
    silenceDebounceTimer = null;
    const snapshot = latestTranscriptText;
    if (!snapshot || snapshot.split(/\s+/).length < 4) return;
    LOG("Silence debounce fired (350ms pause). Forcing endpoint + coach.");
    if (assemblySocket && assemblySocket.readyState === WebSocket.OPEN) {
      try { assemblySocket.send(JSON.stringify({ type: "ForceEndpoint" })); } catch (_) {}
    }
    triggerAiCoach(snapshot, currentSession);
  }, 350);
}

// =========================================================
// AssemblyAI WebSocket Message Handler
// =========================================================

async function handleAssemblyAiMessage(rawData) {
  let msg;
  try {
    msg = typeof rawData === "string" ? JSON.parse(rawData) : rawData;
  } catch (_) { return; }

  // ---- SessionBegins ----
  if (msg.type === "SessionBegins" || msg.message_type === "SessionBegins") {
    LOG("AssemblyAI session started! id:", msg.session_id);
    sendToContentOverlay("Update Engine Status", { status: "LIVE · Ultra-Fast AI Copilot ✓" });
    return;
  }

  // ---- Error ----
  if (msg.type === "error" || msg.error) {
    ERR("AssemblyAI error:", JSON.stringify(msg));
    sendToContentOverlay("Update Engine Status", {
      status: `STT Error: ${msg.error || msg.message || "unknown"}`
    });
    return;
  }

  // ---- Transcript (Turn / PartialTranscript / FinalTranscript) ----
  const isTurnMsg =
    msg.type === "Turn" ||
    msg.message_type === "PartialTranscript" ||
    msg.message_type === "FinalTranscript";

  if (!isTurnMsg) return;

  const text = (msg.transcript || msg.text || "").trim();
  if (!text) return;

  const isFinal =
    msg.type === "Turn"
      ? Boolean(msg.end_of_turn)
      : msg.message_type === "FinalTranscript" || Boolean(msg.isFinal);

  latestTranscriptText = text;
  sendToContentOverlay("Update Live Transcript", { text, isFinal });

  // ---- Trigger 1: end_of_turn === true (server boundary) ----
  if (isFinal) {
    LOG("Trigger 1 (end_of_turn):", text.slice(0, 60));
    resetSilenceDebounce(null);
    await triggerAiCoach(text, currentSession);
    return;
  }

  // ---- Trigger 2: Question-mark partial (starts generating BEFORE speaker finishes!) ----
  const wordCount = text.split(/\s+/).length;
  const now = Date.now();
  if (
    text.includes("?") &&
    wordCount >= 4 &&
    now - lastPartialCoachTimestamp >= PARTIAL_COACH_INTERVAL_MS
  ) {
    lastPartialCoachTimestamp = now;
    LOG("Trigger 2 (Fast question mark):", text.slice(0, 60));
    resetSilenceDebounce(null);
    triggerAiCoach(text, currentSession);
    return;
  }

  // ---- Trigger 3: 350ms silence debounce ----
  if (wordCount >= 4) {
    resetSilenceDebounce(text);
  }
}

// =========================================================
// Engine Start / Stop
// =========================================================

async function startEngine(config) {
  LOG("startEngine:", JSON.stringify({
    hasStreamId: Boolean(config.streamId),
    hasAssemblyKey: Boolean(config.assemblyAiKey),
    aiProvider: config.aiProvider,
    hasCoachKey: Boolean(config.coachKey),
    profile: config.profile,
    tabId: config.tabId
  }));

  await stopEngine();

  // Reset state
  isCoachInFlight = false;
  pendingCoachText = null;
  lastPartialCoachTimestamp = 0;
  latestTranscriptText = "";
  if (silenceDebounceTimer) { clearTimeout(silenceDebounceTimer); silenceDebounceTimer = null; }

  const resolvedProvider =
    config.aiProvider ||
    (config.coachKey?.startsWith("AIza") ? "gemini" : config.geminiKey ? "gemini" : "nvidia");

  const resolvedGeminiKey =
    config.geminiKey ||
    (resolvedProvider === "gemini" || config.coachKey?.startsWith("AIza") ? config.coachKey : null);

  currentSession = {
    assemblyAiKey: config.assemblyAiKey,
    nvidiaKey: config.nvidiaKey || (resolvedProvider !== "gemini" ? config.coachKey : null),
    coachKey: config.coachKey,
    aiProvider: resolvedProvider,
    geminiKey: resolvedGeminiKey,
    profile: config.profile || "interview",
    customContext: config.customContext || "",
    enableVision: typeof config.enableVision === "boolean" ? config.enableVision : true,
    tabId: config.tabId
  };

  LOG("Session resolved:", {
    aiProvider: currentSession.aiProvider,
    hasGeminiKey: Boolean(currentSession.geminiKey),
    hasAssemblyKey: Boolean(currentSession.assemblyAiKey),
    profile: currentSession.profile,
    tabId: currentSession.tabId
  });

  if (!currentSession.assemblyAiKey) throw new Error("AssemblyAI API key missing.");
  if (currentSession.aiProvider === "gemini" && !currentSession.geminiKey) {
    throw new Error("Gemini API key missing.");
  }

  recentTurns = [];

  // Step A: Tab audio capture
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: config.streamId } },
      video: false
    });
  } catch (e) {
    throw new Error(`Audio capture failed: ${e.message}`);
  }

  // Step B: Low-latency AudioContext
  audioContext = new AudioContext({ sampleRate: SAMPLE_RATE });
  const sourceNode = audioContext.createMediaStreamSource(mediaStream);
  sourceNode.connect(audioContext.destination); // passthrough to speakers

  // Step C: AssemblyAI token
  let tempToken;
  try {
    tempToken = await fetchAssemblyAiTempToken(currentSession.assemblyAiKey);
  } catch (e) {
    throw new Error(`AssemblyAI auth failed: ${e.message}`);
  }

  // Step D: Low-latency WebSocket parameters
  // min_turn_silence: 150ms (was 400ms), max_turn_silence: 350ms (was 1000ms)
  // Cuts turn finalization time by 650ms!
  const wsUrl = new URL("wss://streaming.assemblyai.com/v3/ws");
  wsUrl.searchParams.set("sample_rate", String(SAMPLE_RATE));
  wsUrl.searchParams.set("speech_model", "universal-3-6-pro");
  wsUrl.searchParams.set("encoding", "pcm_s16le");
  wsUrl.searchParams.set("format_turns", "true");
  wsUrl.searchParams.set("min_turn_silence", "150");  // Low-latency silence threshold
  wsUrl.searchParams.set("max_turn_silence", "350");  // Force turn closure after 350ms
  wsUrl.searchParams.set("token", tempToken);

  assemblySocket = new WebSocket(wsUrl.toString());
  assemblySocket.binaryType = "arraybuffer";

  assemblySocket.onopen = () => {
    LOG("AssemblyAI WebSocket OPEN.");
    sendToContentOverlay("Update Engine Status", {
      status: `LIVE · Ultra-Fast AI Copilot (${(currentSession.aiProvider || "gemini").toUpperCase()}) ✓`
    });
  };

  assemblySocket.onmessage = (event) => { handleAssemblyAiMessage(event.data); };

  assemblySocket.onerror = () => {
    ERR("AssemblyAI WebSocket ERROR.");
    sendToContentOverlay("Update Engine Status", {
      status: "AssemblyAI WebSocket error — check API key"
    });
  };

  assemblySocket.onclose = (event) => {
    LOG("WS closed. Code:", event.code);
    if (event.code !== 1000) {
      sendToContentOverlay("Update Engine Status", {
        status: `STT Disconnected (${event.code})`
      });
    }
  };

  // Step E: Low-latency AudioWorklet
  const workletUrl = chrome.runtime.getURL("offscreen/pcm-worklet.js");
  try {
    await audioContext.audioWorklet.addModule(workletUrl);
  } catch (e) {
    throw new Error(`AudioWorklet load failed: ${e.message}`);
  }

  workletNode = new AudioWorkletNode(audioContext, "pcm16-chunk-processor");
  workletNode.port.onmessage = (event) => {
    if (
      event.data?.type === "AUDIO_CHUNK" &&
      assemblySocket &&
      assemblySocket.readyState === WebSocket.OPEN
    ) {
      assemblySocket.send(event.data.pcm16Buffer);
    }
  };

  sourceNode.connect(workletNode);
  LOG("Ultra-fast pipeline connected!");

  sendToContentOverlay("Update Engine Status", { status: "Ready · Listening live..." });
  return { ok: true };
}

async function stopEngine() {
  LOG("stopEngine.");
  if (silenceDebounceTimer) { clearTimeout(silenceDebounceTimer); silenceDebounceTimer = null; }
  if (assemblySocket) {
    try {
      if (assemblySocket.readyState === WebSocket.OPEN) {
        assemblySocket.send(JSON.stringify({ type: "Terminate" }));
      }
      assemblySocket.close();
    } catch (_) {}
    assemblySocket = null;
  }
  if (workletNode) { try { workletNode.disconnect(); } catch (_) {} workletNode = null; }
  if (audioContext) { try { await audioContext.close(); } catch (_) {} audioContext = null; }
  if (mediaStream) { mediaStream.getTracks().forEach((t) => t.stop()); mediaStream = null; }
  return { ok: true };
}

// =========================================================
// Message Listener
// =========================================================

if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.target !== "offscreen") return false;

    if (message.action === "Start Engine") {
      startEngine(message)
        .then((res) => sendResponse(res))
        .catch((err) => {
          ERR("startEngine threw:", err.message);
          sendToContentOverlay("Update AI Coach", { advice: `Engine Start Error: ${err.message}`, isError: true });
          sendResponse({ ok: false, error: err.message });
        });
      return true;
    }

    if (message.action === "Manual Coach Trigger") {
      triggerAiCoach(message.promptText, currentSession, message.screenshotDataUrl)
        .then((advice) => sendResponse({ ok: true, advice }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
    }

    if (message.action === "Stop Engine") {
      stopEngine()
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
    }

    return false;
  });

  LOG("Offscreen script loaded and ready.");
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    TEXT_MODEL_CANDIDATES, VISION_MODEL_CANDIDATES, discoverLiveNvidiaModel,
    callNvidiaWithFailover, callGeminiStream, PROFILE_PROMPTS,
    handleAssemblyAiMessage, triggerAiCoach, startEngine, stopEngine,
    _setSessionForTest: (s) => { currentSession = { ...currentSession, ...s }; },
    _getCachedModels: () => ({ cachedWorkingTextModel, cachedWorkingVisionModel }),
    _setCachedWorkingModel: (t, v) => {
      if (t !== undefined) cachedWorkingTextModel = t;
      if (v !== undefined) cachedWorkingVisionModel = v;
    }
  };
}
