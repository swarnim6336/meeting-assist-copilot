// =========================================================
// 2. BACKGROUND SCRIPT (Service Worker)
// =========================================================

const LOG = (...args) => console.log("[BG]", ...args);
const ERR = (...args) => console.error("[BG ERROR]", ...args);

let activeCaptureTabId = null;

// Always close any existing offscreen doc and create a fresh one.
// This prevents stale WebSockets / script state from a previous session.
async function recreateOffscreenDocument() {
  const offscreenUrl = "offscreen/offscreen.html";

  // Close any existing doc (ignore errors if none exists)
  try {
    await chrome.offscreen.closeDocument();
    LOG("Closed existing offscreen document.");
  } catch (_) {
    // No document was open — that's fine
  }

  LOG("Creating fresh offscreen document...");
  await chrome.offscreen.createDocument({
    url: offscreenUrl,
    reasons: ["USER_MEDIA"],
    justification: "Capture tab audio stream and process real-time speech-to-text for Meeting Assist"
  });
  LOG("Fresh offscreen document created.");
}

async function captureActiveTabScreenshot() {
  if (!chrome.tabs.captureVisibleTab) return null;
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 35 });
    return dataUrl || null;
  } catch (e) {
    ERR("Screenshot capture failed:", e.message);
    return null;
  }
}

async function handleBeginCapture(message) {
  LOG("handleBeginCapture:", JSON.stringify({
    tabId: message.tabId,
    aiProvider: message.aiProvider,
    hasCoachKey: Boolean(message.coachKey),
    profile: message.profile
  }));

  const {
    tabId,
    assemblyAiKey,
    aiProvider = "gemini",
    coachKey,
    nvidiaKey,
    profile,
    customContext = "",
    enableVision = true
  } = message;
  activeCaptureTabId = tabId;

  // Step 1: Inject content script & restore HUD visibility if previously closed
  LOG("Step 1: Injecting content.js into tab", tabId);
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content/content.js"] });
    try { await chrome.tabs.sendMessage(tabId, { action: "restore_overlay" }); } catch (_) {}
    LOG("content.js injected and visibility restored.");
  } catch (e) {
    ERR("content.js injection failed:", e.message);
    throw new Error(`Content script injection failed: ${e.message}`);
  }

  // Step 2: Get MediaStream ID
  LOG("Step 2: Getting tab audio stream ID...");
  let streamId;
  try {
    streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
    LOG("streamId:", streamId ? streamId.slice(0, 20) + "..." : "NULL");
  } catch (e) {
    ERR("tabCapture.getMediaStreamId failed:", e.message);
    throw new Error(`Tab audio capture failed: ${e.message}`);
  }
  if (!streamId) throw new Error("tabCapture returned null/empty streamId.");

  // Step 3: Force-recreate offscreen document (always fresh)
  LOG("Step 3: Recreating offscreen document...");
  try {
    await recreateOffscreenDocument();
  } catch (e) {
    ERR("Offscreen document creation failed:", e.message);
    throw new Error(`Offscreen document failed: ${e.message}`);
  }

  // Small settle delay so offscreen.js listener registers
  await new Promise((r) => setTimeout(r, 600));

  // Step 4: Send Start Engine to offscreen
  LOG("Step 4: Sending 'Start Engine' to offscreen...");
  const payload = {
    target: "offscreen",
    action: "Start Engine",
    streamId,
    assemblyAiKey,
    aiProvider,
    coachKey: coachKey || nvidiaKey,
    profile,
    customContext,
    enableVision,
    tabId
  };
  LOG("Payload summary:", JSON.stringify({
    ...payload,
    streamId: "...",
    assemblyAiKey: assemblyAiKey ? "set" : "MISSING",
    coachKey: coachKey ? "set" : "MISSING"
  }));

  let engineResponse;
  try {
    engineResponse = await chrome.runtime.sendMessage(payload);
    LOG("Engine response:", JSON.stringify(engineResponse));
  } catch (e) {
    ERR("Start Engine message failed:", e.message);
    throw new Error(`Engine start failed: ${e.message}`);
  }

  if (engineResponse && !engineResponse.ok) {
    throw new Error(engineResponse.error || "Engine failed to start");
  }

  await chrome.storage.local.set({ isCapturing: true, activeCaptureTabId: tabId });
  LOG("Capture started successfully.");
  return engineResponse || { ok: true };
}

async function handleStopCapture() {
  LOG("handleStopCapture.");
  try {
    await chrome.runtime.sendMessage({ target: "offscreen", action: "Stop Engine" });
  } catch (e) {
    ERR("Stop Engine msg failed (may be normal):", e.message);
  }
  if (activeCaptureTabId) {
    try { await chrome.tabs.sendMessage(activeCaptureTabId, { action: "hide_overlay" }); } catch (_) {}
  }
  await chrome.storage.local.set({ isCapturing: false, activeCaptureTabId: null });
  activeCaptureTabId = null;
  return { ok: true };
}

async function relayToContentScript(payload) {
  let targetTabId = payload.tabId || activeCaptureTabId;
  if (!targetTabId) {
    const stored = await chrome.storage.local.get(["activeCaptureTabId"]);
    targetTabId = stored.activeCaptureTabId;
  }
  if (!targetTabId) {
    ERR("relayToContentScript: no active tab ID. action:", payload.action);
    return { ok: false, error: "No active capture tab ID" };
  }
  try {
    await chrome.tabs.sendMessage(targetTabId, payload);
    return { ok: true };
  } catch (err) {
    ERR("relay failed:", err.message, "| action:", payload.action, "| tabId:", targetTabId);
    return { ok: false, error: err.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.action) return false;
  LOG("Msg:", message.action, "| target:", message.target || "—");

  if (message.action === "Begin Capture") {
    handleBeginCapture(message)
      .then((res) => sendResponse({ ok: true, ...res }))
      .catch((err) => { ERR("Begin Capture error:", err.message); sendResponse({ ok: false, error: err.message }); });
    return true;
  }

  if (message.action === "Stop Capture") {
    handleStopCapture()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Capture Screenshot") {
    captureActiveTabScreenshot()
      .then((screenshotDataUrl) => sendResponse({ ok: true, screenshotDataUrl }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Manual Prompt") {
    LOG("Manual Prompt:", message.promptText?.slice(0, 60));
    captureActiveTabScreenshot()
      .then((screenshotDataUrl) =>
        chrome.runtime.sendMessage({
          target: "offscreen",
          action: "Manual Coach Trigger",
          promptText: message.promptText || "Analyze the current screen and latest question.",
          screenshotDataUrl
        })
      )
      .then((res) => sendResponse(res || { ok: true }))
      .catch((err) => { ERR("Manual Prompt error:", err.message); sendResponse({ ok: false, error: err.message }); });
    return true;
  }

  // Relay offscreen → content
  if (
    message.target === "content" &&
    (message.action === "Update Live Transcript" ||
      message.action === "Update AI Coach" ||
      message.action === "Stream AI Coach" ||
      message.action === "Update Engine Status")
  ) {
    relayToContentScript(message)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  return false;
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    recreateOffscreenDocument,
    captureActiveTabScreenshot,
    handleBeginCapture,
    handleStopCapture,
    relayToContentScript
  };
}
