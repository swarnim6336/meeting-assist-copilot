// =========================================================
// 3. OFFSCREEN SCRIPT (YouTube & Live Meeting Audio + AI Coach Engine)
// =========================================================

const PROFILE_PROMPTS = {
  interview:
    "You are an elite real-time Interview Copilot. Based on the latest transcript, give a direct, natural first-person spoken answer in 2-3 bullet points (starting each bullet with '• '). If a coding/technical question is asked, include a concise ``` code block and time/space complexity.",
  sales:
    "You are an elite real-time B2B Sales Copilot. Give 2 ultra-concise, immediately actionable talking points (starting with '• ', under 45 words total) responding to the latest question or objection.",
  meeting:
    "You are an Executive Business Meeting Copilot. Provide 2 sharp, high-leverage talking points (starting with '• ') addressing the latest statement in the transcript.",
  presentation:
    "You are a Live Presentation & Q&A Defense Copilot. Provide a crisp, confident response to the latest question in 2 short bullets (starting with '• ').",
  negotiation:
    "You are a tactical Negotiation Copilot. Give 2 sharp tactical bullets (starting with '• ', under 45 words total) on anchoring, concessions, or answering the speaker's latest question."
};

// Active NVIDIA NIM Models (meta/llama-3.1-70b-instruct reached EOL on 2026-08-26 and returns HTTP 410)
const TEXT_MODEL_CANDIDATES = [
  "meta/llama-3.3-70b-instruct",
  "meta/llama-3.1-8b-instruct",
  "meta/llama-4-maverick-17b-128e-instruct",
  "meta/llama-4-scout-17b-16e-instruct",
  "nvidia/llama-3.3-nemotron-super-49b-v1"
];

const VISION_MODEL_CANDIDATES = [
  "meta/llama-4-maverick-17b-128e-instruct",
  "meta/llama-4-scout-17b-16e-instruct",
  "meta/llama-3.2-90b-vision-instruct",
  "meta/llama-3.2-11b-vision-instruct"
];

const SAMPLE_RATE = 16000;
const RMS_SILENCE_THRESHOLD = 0.004;

let mediaStream = null;
let audioContext = null;
let workletNode = null;
let assemblySocket = null;
let recentTurns = [];
let cachedWorkingTextModel = null;
let cachedWorkingVisionModel = null;

let latestTranscriptText = "";
let lastCoachedNormalized = "";
let isCoachInFlight = false;
let pendingCoachText = null;
let silenceDebounceTimer = null;
let lastPartialCoachTimestamp = 0;
let currentTurnOrder = -1;
let lastTriggeredQuestionCount = 0;

let currentSession = {
  assemblyAiKey: null,
  nvidiaKey: null,
  profile: "interview",
  customContext: "",
  enableVision: false,
  tabId: null
};

function normalizeForDedup(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function processAudioFrameToPcm16(float32Samples, silenceThreshold = RMS_SILENCE_THRESHOLD) {
  if (!float32Samples || float32Samples.length === 0) {
    return { isSilent: true, rms: 0, pcm16: null };
  }
  let sumSquares = 0;
  for (let i = 0; i < float32Samples.length; i++) {
    sumSquares += float32Samples[i] * float32Samples[i];
  }
  const rms = Math.sqrt(sumSquares / float32Samples.length);
  if (rms < silenceThreshold) {
    return { isSilent: true, rms, pcm16: null };
  }

  const pcm16 = new Int16Array(float32Samples.length);
  for (let i = 0; i < float32Samples.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Samples[i]));
    pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return { isSilent: false, rms, pcm16 };
}

function sendToContentOverlay(action, data) {
  chrome.runtime.sendMessage({
    target: "content",
    action,
    tabId: currentSession.tabId,
    ...data
  });
}

async function fetchAssemblyAiTempToken(assemblyAiKey) {
  const url = "https://streaming.assemblyai.com/v3/token?expires_in_seconds=60";
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: assemblyAiKey
    }
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`AssemblyAI token error (${response.status}): ${errText}`);
  }
  const data = await response.json();
  if (!data.token) {
    throw new Error("AssemblyAI token response missing 'token' field.");
  }
  return data.token;
}

async function requestTabScreenshotIfEnabled(sessionConfig) {
  if (!sessionConfig.enableVision) return null;
  try {
    const res = await chrome.runtime.sendMessage({ action: "Capture Screenshot" });
    return res && res.ok ? res.screenshotDataUrl : null;
  } catch (_) {
    return null;
  }
}

async function discoverLiveNvidiaModel(nvidiaKey) {
  try {
    const res = await fetch("https://integrate.api.nvidia.com/v1/models", {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${nvidiaKey}`
      }
    });
    if (!res.ok) return null;
    const data = await res.json();
    const models = (data?.data || []).map((m) => m.id).filter(Boolean);
    const preferred = models.find(
      (id) =>
        id.includes("llama-3.3-70b") ||
        id.includes("llama-3.1-8b") ||
        id.includes("llama-4") ||
        id.includes("nemotron")
    );
    return preferred || models[0] || null;
  } catch (_) {
    return null;
  }
}

async function callGeminiCompletion(geminiKey, systemPrompt, userContent, screenshotDataUrl = null) {
  const candidateModels = ["gemini-2.5-flash", "gemini-3.8-flash", "gemini-flash-latest"];
  const contents = [];
  const parts = [];
  if (screenshotDataUrl) {
    const base64Data = screenshotDataUrl.replace(/^data:image\/[a-z]+;base64,/, "");
    parts.push({
      inline_data: {
        mime_type: "image/jpeg",
        data: base64Data
      }
    });
  }
  parts.push({ text: typeof userContent === "string" ? userContent : JSON.stringify(userContent) });
  contents.push({ role: "user", parts });

  const payload = {
    contents,
    system_instruction: {
      parts: [{ text: systemPrompt }]
    },
    generationConfig: {
      temperature: 0.2,
      maxOutputTokens: 240
    }
  };

  let lastError = null;
  for (const modelName of candidateModels) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${geminiKey}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        const adviceText = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (adviceText) {
          return { advice: adviceText, modelUsed: modelName };
        }
      } else {
        const errText = await res.text();
        lastError = new Error(`Gemini API (${modelName} HTTP ${res.status}): ${errText}`);
        if (res.status === 403 || res.status === 401) {
          throw lastError; // Stop early on authentication/revocation failure
        }
      }
    } catch (err) {
      lastError = err;
      if (err.message && (err.message.includes("403") || err.message.includes("leaked") || err.message.includes("API key not valid"))) {
        throw err;
      }
    }
  }

  throw lastError || new Error("All Gemini candidate models failed to generate content.");
}

async function callNvidiaChatCompletion(nvidiaKey, model, systemPrompt, userContent) {
  const payload = {
    model,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userContent }
    ],
    temperature: 0.2,
    top_p: 0.7,
    max_tokens: 240,
    stream: false
  };

  return fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${nvidiaKey}`
    },
    body: JSON.stringify(payload)
  });
}

async function triggerAiCoach(inputSentence, sessionConfig = currentSession, explicitScreenshot = null) {
  const cleanSentence = (inputSentence || latestTranscriptText || "").trim();
  const normalized = normalizeForDedup(cleanSentence);
  if (!cleanSentence || normalized.length < 6) return null;

  // Deduplicate unformatted vs formatted turns with identical words
  if (normalized === lastCoachedNormalized && !explicitScreenshot) {
    return null;
  }

  if (isCoachInFlight) {
    pendingCoachText = cleanSentence;
    return null;
  }

  isCoachInFlight = true;
  lastCoachedNormalized = normalized;

  sendToContentOverlay("Update AI Coach", {
    advice: `Analyzing: "${cleanSentence.slice(-85)}"...`,
    profile: sessionConfig.profile,
    isPending: true
  });

  const { nvidiaKey, profile, customContext } = sessionConfig;
  const basePrompt = PROFILE_PROMPTS[profile] || PROFILE_PROMPTS.interview;
  const systemPrompt = customContext
    ? `${basePrompt}\n\nCandidate / User Background Context:\n${customContext}`
    : basePrompt;

  recentTurns.push(cleanSentence);
  if (recentTurns.length > 6) {
    recentTurns.shift();
  }

  const conversationSnippet = recentTurns.join("\n");
  const screenshotDataUrl =
    explicitScreenshot || (await requestTabScreenshotIfEnabled(sessionConfig));

  const userTextPrompt = `Live transcript context:\n${conversationSnippet}\n\nLatest spoken question / statement: "${cleanSentence}"\n\nProvide a direct, actionable response right now:`;

  try {
    let lastErrorText = "";

    // Support both Google Gemini keys (AIza...) and NVIDIA NIM keys (nvapi-...)
    if (nvidiaKey && nvidiaKey.startsWith("AIza")) {
      const result = await callGeminiCompletion(
        nvidiaKey,
        systemPrompt,
        userTextPrompt,
        screenshotDataUrl
      );
      const advice = typeof result === "object" ? result.advice : result;
      const modelUsed = typeof result === "object" ? result.modelUsed : "gemini-2.5-flash";
      sendToContentOverlay("Update AI Coach", {
        advice,
        profile,
        modelUsed,
        sourceSentence: cleanSentence
      });
      return advice;
    }

    if (screenshotDataUrl) {
      const visionQueue = cachedWorkingVisionModel
        ? [
            cachedWorkingVisionModel,
            ...VISION_MODEL_CANDIDATES.filter((m) => m !== cachedWorkingVisionModel)
          ]
        : VISION_MODEL_CANDIDATES;

      const multimodalContent = [
        { type: "text", text: userTextPrompt },
        { type: "image_url", image_url: { url: screenshotDataUrl } }
      ];

      for (const visionModel of visionQueue) {
        const res = await callNvidiaChatCompletion(
          nvidiaKey,
          visionModel,
          systemPrompt,
          multimodalContent
        );
        if (res.ok) {
          cachedWorkingVisionModel = visionModel;
          const result = await res.json();
          const advice =
            result?.choices?.[0]?.message?.content?.trim() ||
            "• Clarify the core constraint first, then walk through your approach step-by-step.";
          sendToContentOverlay("Update AI Coach", {
            advice,
            profile,
            modelUsed: visionModel,
            sourceSentence: cleanSentence
          });
          return advice;
        }
        lastErrorText = `HTTP ${res.status}: ${await res.text()}`;
        if (res.status === 401 || res.status === 403) {
          throw new Error(`NVIDIA API Auth Error (${res.status}): Check your nvapi- key.`);
        }
      }
    }

    const textQueue = cachedWorkingTextModel
      ? [
          cachedWorkingTextModel,
          ...TEXT_MODEL_CANDIDATES.filter((m) => m !== cachedWorkingTextModel)
        ]
      : [...TEXT_MODEL_CANDIDATES];

    for (const textModel of textQueue) {
      const res = await callNvidiaChatCompletion(
        nvidiaKey,
        textModel,
        systemPrompt,
        userTextPrompt
      );
      if (res.ok) {
        cachedWorkingTextModel = textModel;
        const result = await res.json();
        const advice =
          result?.choices?.[0]?.message?.content?.trim() ||
          "• Clarify the core constraint first, then walk through your approach step-by-step.";
        sendToContentOverlay("Update AI Coach", {
          advice,
          profile,
          modelUsed: textModel,
          sourceSentence: cleanSentence
        });
        return advice;
      }
      lastErrorText = `HTTP ${res.status}: ${await res.text()}`;
      if (res.status === 401 || res.status === 403) {
        throw new Error(`NVIDIA API Auth Error (${res.status}): Check your nvapi- key.`);
      }
    }

    const discoveredModel = await discoverLiveNvidiaModel(nvidiaKey);
    if (discoveredModel) {
      const res = await callNvidiaChatCompletion(
        nvidiaKey,
        discoveredModel,
        systemPrompt,
        userTextPrompt
      );
      if (res.ok) {
        cachedWorkingTextModel = discoveredModel;
        const result = await res.json();
        const advice =
          result?.choices?.[0]?.message?.content?.trim() ||
          "• Clarify the core constraint first, then walk through your approach step-by-step.";
        sendToContentOverlay("Update AI Coach", {
          advice,
          profile,
          modelUsed: discoveredModel,
          sourceSentence: cleanSentence
        });
        return advice;
      }
      lastErrorText = `HTTP ${res.status}: ${await res.text()}`;
    }

    throw new Error(`NVIDIA API ${lastErrorText}`);
  } catch (err) {
    const fallbackMsg = `[Coach API Error] ${err.message}`;
    sendToContentOverlay("Update AI Coach", {
      advice: fallbackMsg,
      profile,
      isError: true
    });
    return fallbackMsg;
  } finally {
    isCoachInFlight = false;
    if (pendingCoachText && normalizeForDedup(pendingCoachText) !== lastCoachedNormalized) {
      const nextText = pendingCoachText;
      pendingCoachText = null;
      triggerAiCoach(nextText, sessionConfig);
    }
  }
}

async function handleAssemblyAiMessage(rawData) {
  let msg;
  try {
    msg = typeof rawData === "string" ? JSON.parse(rawData) : rawData;
  } catch (_) {
    return;
  }

  if (
    msg.type === "Turn" ||
    msg.message_type === "PartialTranscript" ||
    msg.message_type === "FinalTranscript"
  ) {
    const text = (msg.transcript || msg.text || "").trim();
    if (!text) return;

    if (typeof msg.turn_order === "number" && msg.turn_order !== currentTurnOrder) {
      currentTurnOrder = msg.turn_order;
      lastTriggeredQuestionCount = 0;
    }

    latestTranscriptText = text;

    const isFinal =
      msg.type === "Turn"
        ? Boolean(msg.end_of_turn)
        : msg.message_type === "FinalTranscript" || Boolean(msg.isFinal);

    sendToContentOverlay("Update Live Transcript", {
      text,
      isFinal
    });

    if (silenceDebounceTimer) {
      clearTimeout(silenceDebounceTimer);
      silenceDebounceTimer = null;
    }

    if (isFinal) {
      lastPartialCoachTimestamp = Date.now();
      await triggerAiCoach(text, currentSession);
      return;
    }

    const now = Date.now();
    const questionMatches = text.match(/\?/g);
    const questionCount = questionMatches ? questionMatches.length : 0;
    const wordCount = text.split(/\s+/).length;

    // Trigger immediately when a NEW question mark (?) appears in continuous YouTube speech
    if (
      questionCount > lastTriggeredQuestionCount &&
      wordCount >= 5 &&
      now - lastPartialCoachTimestamp > 2800
    ) {
      lastTriggeredQuestionCount = questionCount;
      lastPartialCoachTimestamp = now;
      await triggerAiCoach(text, currentSession);
      return;
    }

    // 1.2s pause debounce timer (when speaker pauses or user pauses YouTube)
    if (wordCount >= 5 && normalizeForDedup(text) !== lastCoachedNormalized) {
      silenceDebounceTimer = setTimeout(() => {
        if (assemblySocket && assemblySocket.readyState === 1) {
          try {
            assemblySocket.send(JSON.stringify({ type: "ForceEndpoint" }));
          } catch (_) {}
        }
        triggerAiCoach(latestTranscriptText, currentSession);
      }, 1200);
    }
  }
}

async function startEngine(config) {
  await stopEngine();

  currentSession = {
    assemblyAiKey: config.assemblyAiKey,
    nvidiaKey: config.nvidiaKey,
    profile: config.profile || "interview",
    customContext: config.customContext || "",
    enableVision: typeof config.enableVision === "boolean" ? config.enableVision : false,
    tabId: config.tabId
  };
  recentTurns = [];
  latestTranscriptText = "";
  lastCoachedNormalized = "";
  isCoachInFlight = false;
  pendingCoachText = null;
  currentTurnOrder = -1;
  lastTriggeredQuestionCount = 0;

  mediaStream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: config.streamId
      }
    },
    video: false
  });

  audioContext = new AudioContext({ sampleRate: SAMPLE_RATE });
  const sourceNode = audioContext.createMediaStreamSource(mediaStream);
  sourceNode.connect(audioContext.destination);

  const tempToken = await fetchAssemblyAiTempToken(currentSession.assemblyAiKey);
  const wsUrl = new URL("wss://streaming.assemblyai.com/v3/ws");
  wsUrl.searchParams.set("sample_rate", String(SAMPLE_RATE));
  wsUrl.searchParams.set("speech_model", "universal-3-6-pro");
  wsUrl.searchParams.set("encoding", "pcm_s16le");
  wsUrl.searchParams.set("format_turns", "true");
  wsUrl.searchParams.set("min_turn_silence", "400");
  wsUrl.searchParams.set("max_turn_silence", "1000");
  wsUrl.searchParams.set("token", tempToken);

  assemblySocket = new WebSocket(wsUrl.toString());
  assemblySocket.binaryType = "arraybuffer";

  assemblySocket.onopen = () => {
    sendToContentOverlay("Update Engine Status", {
      status: "COPILOT · LLAMA-3.3-70B"
    });
  };

  assemblySocket.onmessage = (event) => {
    handleAssemblyAiMessage(event.data);
  };

  assemblySocket.onerror = () => {
    sendToContentOverlay("Update Engine Status", {
      status: "WEBSOCKET ERROR — CHECK KEY"
    });
  };

  await audioContext.audioWorklet.addModule("pcm-worklet.js");
  workletNode = new AudioWorkletNode(audioContext, "pcm16-chunk-processor");

  workletNode.port.onmessage = (event) => {
    if (
      event.data?.type === "AUDIO_CHUNK" &&
      assemblySocket &&
      assemblySocket.readyState === WebSocket.OPEN
    ) {
      assemblySocket.send(event.data.pcm16Buffer);
    }
  };

  sourceNode.connect(workletNode);
  return { ok: true };
}

async function stopEngine() {
  if (silenceDebounceTimer) {
    clearTimeout(silenceDebounceTimer);
    silenceDebounceTimer = null;
  }

  if (assemblySocket) {
    try {
      if (assemblySocket.readyState === WebSocket.OPEN) {
        assemblySocket.send(JSON.stringify({ type: "Terminate" }));
      }
      assemblySocket.close();
    } catch (_) {}
    assemblySocket = null;
  }

  if (workletNode) {
    try {
      workletNode.disconnect();
    } catch (_) {}
    workletNode = null;
  }

  if (audioContext) {
    try {
      await audioContext.close();
    } catch (_) {}
    audioContext = null;
  }

  if (mediaStream) {
    mediaStream.getTracks().forEach((track) => track.stop());
    mediaStream = null;
  }

  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.target !== "offscreen") return false;

  if (message.action === "Start Engine") {
    startEngine(message)
      .then((res) => sendResponse(res))
      .catch((err) => {
        sendToContentOverlay("Update AI Coach", {
          advice: `Engine Start Error: ${err.message}`,
          isError: true
        });
        sendResponse({ ok: false, error: err.message });
      });
    return true;
  }

  if (message.action === "Manual Coach Trigger") {
    const queryToUse =
      (message.promptText && message.promptText.trim()) ||
      latestTranscriptText ||
      "Analyze the current screen and latest question.";
    lastCoachedNormalized = ""; // Force fresh execution on manual trigger
    triggerAiCoach(queryToUse, currentSession, message.screenshotDataUrl)
      .then((advice) => sendResponse({ ok: true, advice }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.action === "Stop Engine") {
    stopEngine()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  return false;
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    PROFILE_PROMPTS,
    TEXT_MODEL_CANDIDATES,
    VISION_MODEL_CANDIDATES,
    processAudioFrameToPcm16,
    handleAssemblyAiMessage,
    callGeminiCompletion,
    triggerAiCoach,
    startEngine,
    stopEngine,
    _setSessionForTest: (s) => {
      currentSession = { ...currentSession, ...s };
      cachedWorkingTextModel = null;
      cachedWorkingVisionModel = null;
      latestTranscriptText = "";
      lastCoachedNormalized = "";
      isCoachInFlight = false;
      pendingCoachText = null;
      lastPartialCoachTimestamp = 0;
      currentTurnOrder = -1;
      lastTriggeredQuestionCount = 0;
    }
  };
}
