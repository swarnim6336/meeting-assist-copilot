// =========================================================
// 4. CONTENT SCRIPT (v3.1 Matte Carbon, Titanium & Signal Amber HUD)
// =========================================================

(function initMeetingAssistOverlay() {
  if (window.__MEETING_ASSIST_OVERLAY_INJECTED__) {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) {
      existing.style.display = "block";
    }
    if (typeof window.__MA_RESET_HIDDEN__ === "function") {
      window.__MA_RESET_HIDDEN__();
    }
    return;
  }
  window.__MEETING_ASSIST_OVERLAY_INJECTED__ = true;

  const DEFAULT_PLACEHOLDER = "Listening for question or dialogue...";
  let isClickThrough = false;
  let isHidden = false;
  let isMinimized = false;
  let posX = null;
  let posY = null;
  let rawCoachAdvice = "";

  window.__MA_RESET_HIDDEN__ = () => {
    isHidden = false;
  };

  function getActiveTranscriptPrompt() {
    const transcriptEl = document.getElementById("ma-transcript-text");
    if (!transcriptEl) return "";
    const text = transcriptEl.textContent.trim();
    return text === DEFAULT_PLACEHOLDER ? "" : text;
  }

  function formatCoachAdviceHtml(text, isPending, isError) {
    if (!text) return "";
    const escaped = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    if (isPending) {
      return `
        <div class="shimmer-box">
          <div class="shimmer-header">
            <span class="pulse-ring"></span>
            <span>PROCESSING AUDIO STREAM...</span>
          </div>
          <div class="shimmer-quote">${escaped}</div>
        </div>
      `;
    }

    if (isError) {
      return `<div class="error-card">${escaped}</div>`;
    }

    const parts = escaped.split(/```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g);
    let html = "";

    for (let i = 0; i < parts.length; i += 3) {
      const prose = (parts[i] || "").trim();
      const lang = parts[i + 1] || "code";
      const code = parts[i + 2];

      if (prose) {
        const lines = prose
          .split(/\n+/)
          .map((l) => l.trim())
          .filter(Boolean);
        html += '<div class="bullet-list">';
        for (const line of lines) {
          const cleanLine = line.replace(/^[•\-\*]\s*/, "");
          const bolded = cleanLine.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
          html += `
            <div class="bullet-card">
              <span class="bullet-dot">▸</span>
              <span class="bullet-body">${bolded}</span>
            </div>
          `;
        }
        html += "</div>";
      }

      if (typeof code === "string") {
        html += `
          <div class="code-card">
            <div class="code-header">
              <span>${lang.toUpperCase()}</span>
            </div>
            <pre><code>${code.trim()}</code></pre>
          </div>
        `;
      }
    }

    return (
      html ||
      `<div class="bullet-card"><span class="bullet-dot">▸</span><span class="bullet-body">${escaped}</span></div>`
    );
  }

  function createOverlayElement() {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) return existing;

    const container = document.createElement("div");
    container.id = "meeting-assist-overlay";
    Object.assign(container.style, {
      position: "fixed",
      top: "24px",
      right: "24px",
      width: "430px",
      zIndex: "2147483647",
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      transition: "opacity 0.18s ease"
    });

    container.innerHTML = `
      <style>
        #meeting-assist-overlay * {
          box-sizing: border-box;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        .ma-hud {
          background: rgba(10, 10, 12, 0.94);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-radius: 12px;
          border: 1px solid #27272a;
          box-shadow:
            0 24px 54px rgba(0, 0, 0, 0.85),
            0 1px 0 rgba(255, 255, 255, 0.07) inset;
          color: #f4f4f5;
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }
        .ma-topbar {
          padding: 9px 13px;
          background: #121215;
          border-bottom: 1px solid #27272a;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: grab;
          user-select: none;
        }
        .ma-topbar:active {
          cursor: grabbing;
        }
        .ma-brand-cluster {
          display: flex;
          align-items: center;
          gap: 9px;
        }
        .ma-eq {
          display: flex;
          align-items: flex-end;
          gap: 2px;
          height: 12px;
          padding: 0 2px;
        }
        .ma-eq span {
          width: 2.5px;
          background: #f59e0b;
          border-radius: 1px;
          animation: maEqPulse 1s ease-in-out infinite;
        }
        .ma-eq span:nth-child(1) { height: 5px; animation-delay: 0s; }
        .ma-eq span:nth-child(2) { height: 11px; animation-delay: 0.18s; }
        .ma-eq span:nth-child(3) { height: 7px; animation-delay: 0.35s; }
        .ma-eq span:nth-child(4) { height: 10px; animation-delay: 0.12s; }
        @keyframes maEqPulse {
          0%, 100% { transform: scaleY(0.4); opacity: 0.65; }
          50% { transform: scaleY(1); opacity: 1; }
        }
        #ma-status-label {
          font-size: 11px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          letter-spacing: -0.01em;
          color: #e4e4e7;
        }
        .ma-controls {
          display: flex;
          align-items: center;
          gap: 5px;
        }
        .ma-btn-primary {
          background: #f59e0b;
          color: #09090b;
          border: 1px solid #fbbf24;
          border-radius: 6px;
          padding: 3px 8px;
          font-size: 10.5px;
          font-weight: 700;
          cursor: pointer;
          transition: background 0.12s ease;
        }
        .ma-btn-primary:hover {
          background: #fbbf24;
        }
        .ma-btn-icon {
          background: #18181b;
          border: 1px solid #27272a;
          color: #a1a1aa;
          border-radius: 6px;
          padding: 3px 7px;
          font-size: 10px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          cursor: pointer;
          transition: background 0.14s ease, color 0.14s ease, border-color 0.14s ease;
        }
        .ma-btn-icon:hover {
          background: #27272a;
          color: #f4f4f5;
          border-color: #3f3f46;
        }
        .ma-section-transcript {
          padding: 10px 14px;
          background: #0c0c0e;
          border-bottom: 1px solid #27272a;
          max-height: 92px;
          overflow-y: auto;
        }
        .ma-section-label {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 9.5px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #71717a;
          margin-bottom: 5px;
        }
        #ma-transcript-text {
          font-size: 12px;
          line-height: 1.48;
          color: #d4d4d8;
          font-weight: 400;
        }
        .ma-section-coach {
          padding: 12px 14px;
          background: #101013;
          min-height: 118px;
          max-height: 260px;
          overflow-y: auto;
        }
        .ma-coach-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .ma-coach-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 10px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          text-transform: uppercase;
          letter-spacing: 0.07em;
          color: #f59e0b;
        }
        #ma-coach-text {
          font-size: 12.8px;
          line-height: 1.52;
          color: #f4f4f5;
        }
        .bullet-list {
          display: flex;
          flex-direction: column;
          gap: 7px;
        }
        .bullet-card {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          background: #16161a;
          border: 1px solid #27272a;
          border-left: 2.5px solid #f59e0b;
          border-radius: 7px;
          padding: 8px 10px;
        }
        .bullet-dot {
          color: #f59e0b;
          font-size: 11px;
          line-height: 1.4;
          flex-shrink: 0;
        }
        .bullet-body {
          color: #f4f4f5;
          font-size: 12.5px;
          line-height: 1.48;
          font-weight: 500;
        }
        .bullet-body strong {
          color: #fbbf24;
          font-weight: 700;
        }
        .code-card {
          margin-top: 8px;
          background: #09090b;
          border: 1px solid #27272a;
          border-radius: 7px;
          overflow: hidden;
        }
        .code-header {
          padding: 4px 10px;
          background: #141417;
          border-bottom: 1px solid #27272a;
          font-size: 9.5px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          color: #a1a1aa;
          letter-spacing: 0.06em;
        }
        .code-card pre {
          margin: 0;
          padding: 9px 11px;
          overflow-x: auto;
          font-family: 'JetBrains Mono', 'Fira Code', monospace;
          font-size: 11.5px;
          color: #34d399;
          line-height: 1.45;
        }
        .shimmer-box {
          padding: 10px 12px;
          border-radius: 8px;
          background: rgba(245, 158, 11, 0.08);
          border: 1px solid rgba(245, 158, 11, 0.3);
        }
        .shimmer-header {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 10.5px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          color: #fbbf24;
          margin-bottom: 4px;
        }
        .pulse-ring {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #f59e0b;
          box-shadow: 0 0 8px #f59e0b;
          animation: maEqPulse 0.9s infinite;
        }
        .shimmer-quote {
          font-size: 11px;
          color: #a1a1aa;
          font-style: italic;
        }
        .error-card {
          padding: 9px 11px;
          border-radius: 7px;
          background: rgba(239, 68, 68, 0.12);
          border: 1px solid rgba(239, 68, 68, 0.35);
          color: #fca5a5;
          font-size: 11.5px;
        }
        .ma-footer {
          padding: 8px 12px;
          background: #0c0c0e;
          border-top: 1px solid #27272a;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #ma-manual-input {
          flex: 1;
          background: #141417;
          border: 1px solid #27272a;
          border-radius: 6px;
          color: #f4f4f5;
          font-size: 11.5px;
          padding: 6px 10px;
          outline: none;
          transition: border-color 0.15s ease;
        }
        #ma-manual-input:focus {
          border-color: #f59e0b;
        }
        .ma-hotkey-hint {
          font-size: 9.5px;
          font-family: 'JetBrains Mono', monospace;
          color: #71717a;
          white-space: nowrap;
        }
      </style>

      <div class="ma-hud" id="ma-hud-body">
        <!-- TOP COMMAND BAR -->
        <div class="ma-topbar" id="ma-header">
          <div class="ma-brand-cluster">
            <div class="ma-eq">
              <span></span><span></span><span></span><span></span>
            </div>
            <span id="ma-status-label">COPILOT · LLAMA-3.3-70B</span>
          </div>
          <div class="ma-controls">
            <button id="ma-answer-now-btn" class="ma-btn-primary" title="Force Instant Answer">⚡ Answer</button>
            <button id="ma-snap-btn" class="ma-btn-icon" title="Analyze Screen + Question">Vision</button>
            <span id="ma-mode-pill" class="ma-btn-icon" title="Toggle Click-Through (Ctrl+M)">Ctrl+M</span>
            <button id="ma-min-btn" class="ma-btn-icon" title="Minimize">_</button>
            <button id="ma-close-btn" class="ma-btn-icon" title="Hide HUD (Ctrl+\\)">×</button>
          </div>
        </div>

        <div id="ma-collapsible-area">
          <!-- LIVE TRANSCRIPT STREAM -->
          <div class="ma-section-transcript" id="ma-top-half">
            <div class="ma-section-label">
              <span>LIVE AUDIO STREAM</span>
              <span id="ma-turn-badge" style="color:#10b981;">● LISTENING</span>
            </div>
            <div id="ma-transcript-text">${DEFAULT_PLACEHOLDER}</div>
          </div>

          <!-- AI COPILOT RESPONSE CARDS -->
          <div class="ma-section-coach" id="ma-bottom-half">
            <div class="ma-coach-header">
              <span class="ma-coach-badge">▲ TACTICAL RESPONSE</span>
              <button id="ma-copy-btn" class="ma-btn-icon" title="Copy Response">Copy</button>
            </div>
            <div id="ma-coach-text">
              <div class="bullet-card">
                <span class="bullet-dot">▸</span>
                <span class="bullet-body">Responses trigger automatically on questions (<strong>?</strong>) or brief pauses—or click <strong>⚡ Answer</strong> anytime.</span>
              </div>
            </div>
          </div>

          <!-- COMMAND INPUT FOOTER -->
          <div class="ma-footer" id="ma-footer">
            <input id="ma-manual-input" type="text" placeholder="Ask follow-up or press Enter to answer live stream..." />
            <span class="ma-hotkey-hint">↵ Enter</span>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(container);

    const closeBtn = container.querySelector("#ma-close-btn");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        isHidden = true;
        container.style.display = "none";
      });
    }

    const minBtn = container.querySelector("#ma-min-btn");
    if (minBtn) {
      minBtn.addEventListener("click", () => {
        isMinimized = !isMinimized;
        const area = document.getElementById("ma-collapsible-area");
        if (area) {
          area.style.display = isMinimized ? "none" : "block";
        }
        minBtn.textContent = isMinimized ? "□" : "_";
      });
    }

    const copyBtn = container.querySelector("#ma-copy-btn");
    if (copyBtn) {
      copyBtn.addEventListener("click", () => {
        if (!rawCoachAdvice || !navigator.clipboard) return;
        navigator.clipboard.writeText(rawCoachAdvice);
        copyBtn.textContent = "Copied!";
        setTimeout(() => {
          copyBtn.textContent = "Copy";
        }, 1400);
      });
    }

    const answerNowBtn = container.querySelector("#ma-answer-now-btn");
    if (answerNowBtn) {
      answerNowBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({
          action: "Manual Prompt",
          promptText: getActiveTranscriptPrompt(),
          includeScreen: false
        });
      });
    }

    const snapBtn = container.querySelector("#ma-snap-btn");
    if (snapBtn) {
      snapBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({
          action: "Manual Prompt",
          promptText:
            getActiveTranscriptPrompt() ||
            "Solve the coding problem or answer the question currently visible on my screen.",
          includeScreen: true
        });
      });
    }

    const manualInput = container.querySelector("#ma-manual-input");
    if (manualInput) {
      manualInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          const promptText = manualInput.value.trim() || getActiveTranscriptPrompt();
          manualInput.value = "";
          chrome.runtime.sendMessage({
            action: "Manual Prompt",
            promptText,
            includeScreen: false
          });
        }
      });
    }

    const header = container.querySelector("#ma-header");
    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    if (header) {
      header.addEventListener("mousedown", (e) => {
        if (isClickThrough) return;
        isDragging = true;
        const rect = container.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
      });
      window.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        posX = e.clientX - offsetX;
        posY = e.clientY - offsetY;
        container.style.left = `${posX}px`;
        container.style.top = `${posY}px`;
        container.style.right = "auto";
        container.style.bottom = "auto";
      });
      window.addEventListener("mouseup", () => {
        isDragging = false;
      });
    }

    return container;
  }

  const overlay = createOverlayElement();

  function handleStealthKeydown(e) {
    const isMod = e.ctrlKey || e.metaKey;
    if (!isMod) return;

    if (e.key.toLowerCase() === "m") {
      e.preventDefault();
      isClickThrough = !isClickThrough;
      overlay.style.pointerEvents = isClickThrough ? "none" : "auto";
      overlay.style.opacity = isClickThrough ? "0.52" : "1";
      const pill = document.getElementById("ma-mode-pill");
      if (pill) {
        pill.textContent = isClickThrough ? "Ghost ON" : "Ctrl+M";
      }
      return;
    }

    if (e.key === "\\") {
      e.preventDefault();
      isHidden = !isHidden;
      overlay.style.display = isHidden ? "none" : "block";
      return;
    }

    const step = 40;
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
      e.preventDefault();
      const rect = overlay.getBoundingClientRect
        ? overlay.getBoundingClientRect()
        : { left: posX || 100, top: posY || 24 };
      posX = posX !== null ? posX : rect.left || 100;
      posY = posY !== null ? posY : rect.top || 24;

      if (e.key === "ArrowUp") posY = Math.max(0, posY - step);
      if (e.key === "ArrowDown") posY += step;
      if (e.key === "ArrowLeft") posX = Math.max(0, posX - step);
      if (e.key === "ArrowRight") posX += step;

      overlay.style.left = `${posX}px`;
      overlay.style.top = `${posY}px`;
      overlay.style.right = "auto";
      overlay.style.bottom = "auto";
    }
  }

  window.addEventListener("keydown", handleStealthKeydown);

  function handleContentMessage(message) {
    if (!message || !message.action) return;
    if (!isHidden) {
      overlay.style.display = "block";
    }

    if (message.action === "Update Live Transcript") {
      const transcriptEl = document.getElementById("ma-transcript-text");
      const turnBadge = document.getElementById("ma-turn-badge");
      if (transcriptEl) {
        transcriptEl.textContent = message.text;
        transcriptEl.style.opacity = message.isFinal ? "1" : "0.85";
      }
      if (turnBadge) {
        turnBadge.textContent = message.isFinal ? "● TURN COMPLETE" : "● STREAMING";
      }
    }

    if (message.action === "Update AI Coach") {
      const coachEl = document.getElementById("ma-coach-text");
      if (coachEl) {
        rawCoachAdvice = message.advice || "";
        coachEl.textContent = rawCoachAdvice;
        coachEl.innerHTML = formatCoachAdviceHtml(
          rawCoachAdvice,
          Boolean(message.isPending),
          Boolean(message.isError)
        );
      }
    }

    if (message.action === "Update Engine Status") {
      const statusEl = document.getElementById("ma-status-label");
      if (statusEl && message.status) {
        statusEl.textContent = message.status;
      }
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleContentMessage(message);
    if (sendResponse) sendResponse({ ok: true });
    return false;
  });

  if (typeof module !== "undefined" && module.exports) {
    module.exports = {
      createOverlayElement,
      handleContentMessage,
      handleStealthKeydown,
      formatCoachAdviceHtml,
      _getOverlayState: () => ({ isClickThrough, isHidden, posX, posY, overlay })
    };
  }
})();
