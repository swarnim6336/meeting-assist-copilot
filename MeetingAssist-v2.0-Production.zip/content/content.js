// =========================================================
// 4. CONTENT SCRIPT (Cheating Daddy Stealth Overlay + Shortcuts)
// =========================================================

(function initMeetingAssistOverlay() {
  if (window.MEETING_ASSIST_OVERLAY_INJECTED) {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) existing.style.display = "flex";
    return;
  }
  window.MEETING_ASSIST_OVERLAY_INJECTED = true;

  let isClickThrough = false;
  let isHidden = false;
  let posX = null;
  let posY = null;

  function createOverlayElement() {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) return existing;

    const container = document.createElement("div");
    container.id = "meeting-assist-overlay";
    Object.assign(container.style, {
      position: "fixed",
      top: "24px",
      right: "24px",
      width: "410px",
      minHeight: "250px",
      backgroundColor: "rgba(10, 12, 18, 0.88)",
      color: "#f8fafc",
      borderRadius: "12px",
      border: "1px solid rgba(255, 255, 255, 0.14)",
      boxShadow: "0 16px 40px rgba(0, 0, 0, 0.65)",
      zIndex: "2147483647",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      backdropFilter: "blur(12px)",
      transition: "opacity 0.15s ease"
    });

    container.innerHTML = `
      <div id="ma-header" style="
        padding: 7px 12px;
        background: rgba(255, 255, 255, 0.06);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: move;
        user-select: none;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.03em;
        color: #94a3b8;
      ">
        <span id="ma-status-label">● STEALTH COPILOT LIVE</span>
        <div style="display: flex; align-items: center; gap: 6px;">
          <button id="ma-answer-now-btn" title="Instantly analyze current transcript (⚡)" style="
            background: rgba(239,68,68,0.18);
            border: 1px solid rgba(239,68,68,0.45);
            color: #fca5a5;
            cursor: pointer;
            font-size: 10px;
            font-weight: 700;
            line-height: 1;
            padding: 2px 7px;
            border-radius: 4px;
            letter-spacing: 0.02em;
          ">⚡ Answer Now</button>
          <span id="ma-mode-pill" style="
            font-size: 9.5px;
            padding: 2px 6px;
            border-radius: 4px;
            background: rgba(255,255,255,0.08);
            color: #cbd5e1;
          ">Ctrl+M: Interactive</span>
          <button id="ma-close-btn" title="Hide (Ctrl+\\)" style="
            background: transparent;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 14px;
            line-height: 1;
            padding: 0 4px;
          ">×</button>
        </div>
      </div>

      <!-- TOP HALF: LIVE INTERVIEWER TRANSCRIPT -->
      <div id="ma-top-half" style="
        padding: 10px 14px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        min-height: 72px;
        max-height: 110px;
        overflow-y: auto;
      ">
        <div style="font-size: 10px; text-transform: uppercase; letter-spacing: 0.06em; color: #64748b; margin-bottom: 4px; font-weight: 600;">
          Interviewer / Live Audio
        </div>
        <div id="ma-transcript-text" style="font-size: 12.5px; line-height: 1.45; color: #f1f5f9;">
          Listening for interviewer question...
        </div>
      </div>

      <!-- BOTTOM HALF: AI COACH (Red Tactical Answer / Code) -->
      <div id="ma-bottom-half" style="
        flex: 1;
        padding: 12px 14px;
        background: rgba(239, 68, 68, 0.07);
        min-height: 105px;
        max-height: 220px;
        overflow-y: auto;
      ">
        <div style="font-size: 10px; text-transform: uppercase; letter-spacing: 0.06em; color: #f87171; margin-bottom: 4px; font-weight: 700;">
          AI Answer & Screen Solution (Llama 3)
        </div>
        <div id="ma-coach-text" style="font-size: 13px; line-height: 1.48; color: #ff4d4d; font-weight: 600; white-space: pre-wrap;">
          Answers and code solutions will appear here automatically or when you press Enter.
        </div>
      </div>

      <!-- CHEATING DADDY QUICK PROMPT BAR -->
      <div id="ma-footer" style="
        padding: 6px 10px;
        background: rgba(0, 0, 0, 0.35);
        border-top: 1px solid rgba(255, 255, 255, 0.08);
        display: flex;
        gap: 6px;
      ">
        <input id="ma-manual-input" type="text" placeholder="Type question or press Enter to solve screen..." style="
          flex: 1;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 5px;
          color: #f8fafc;
          font-size: 11.5px;
          padding: 5px 8px;
          outline: none;
        " />
      </div>
    `;

    document.body.appendChild(container);

    const closeBtn = container.querySelector("#ma-close-btn");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        isHidden = true;
        container.style.display = "none";
      });
    }

    // ⚡ Answer Now button — fires an instant coach call on whatever is in the transcript
    const answerNowBtn = container.querySelector("#ma-answer-now-btn");
    if (answerNowBtn) {
      answerNowBtn.addEventListener("click", (e) => {
        e.stopPropagation(); // don't trigger drag
        const transcriptEl = document.getElementById("ma-transcript-text");
        const currentText = (transcriptEl && transcriptEl.textContent.trim()) ||
          "Analyze the current screen and latest question.";
        const coachEl = document.getElementById("ma-coach-text");
        if (coachEl) coachEl.textContent = "⚡ Analyzing...";
        chrome.runtime.sendMessage({ action: "Manual Prompt", promptText: currentText });
      });
    }

    const manualInput = container.querySelector("#ma-manual-input");
    if (manualInput) {
      manualInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          const promptText =
            manualInput.value.trim() ||
            "Solve the coding problem or answer the question currently visible on my screen.";
          manualInput.value = "";
          const coachEl = document.getElementById("ma-coach-text");
          if (coachEl) {
            coachEl.textContent = "Analyzing screen + audio context...";
          }
          chrome.runtime.sendMessage({
            action: "Manual Prompt",
            promptText
          });
        }
      });
    }

    // Mouse Dragging Support
    const header = container.querySelector("#ma-header");
    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    if (header) {
      header.addEventListener("mousedown", (e) => {
        if (isClickThrough) return;
        isDragging = true;
        const rect = container.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
      });

      window.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        posX = e.clientX - offsetX;
        posY = e.clientY - offsetY;
        container.style.left = `${posX}px`;
        container.style.top = `${posY}px`;
        container.style.right = "auto";
        container.style.bottom = "auto";
      });

      window.addEventListener("mouseup", () => {
        isDragging = false;
      });
    }

    return container;
  }

  const overlay = createOverlayElement();

  // Cheating Daddy Keyboard Shortcuts:
  // 1. Ctrl/Cmd + M -> Toggle Click-Through Mode (pointer-events: none)
  // 2. Ctrl/Cmd + \ -> Toggle Visibility (Stealth Hide/Show)
  // 3. Ctrl/Cmd + Arrow Keys -> Move Overlay Window by 40px increments
  function handleStealthKeydown(e) {
    const isMod = e.ctrlKey || e.metaKey;
    if (!isMod) return;

    if (e.key.toLowerCase() === "m") {
      e.preventDefault();
      isClickThrough = !isClickThrough;
      overlay.style.pointerEvents = isClickThrough ? "none" : "auto";
      overlay.style.opacity = isClickThrough ? "0.55" : "1";
      const pill = document.getElementById("ma-mode-pill");
      if (pill) {
        pill.textContent = isClickThrough ? "Ctrl+M: Click-Through ON" : "Ctrl+M: Interactive";
      }
      return;
    }

    if (e.key === "\\") {
      e.preventDefault();
      isHidden = !isHidden;
      overlay.style.display = isHidden ? "none" : "flex";
      return;
    }

    const step = 40;
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
      e.preventDefault();
      const rect = overlay.getBoundingClientRect
        ? overlay.getBoundingClientRect()
        : { left: posX || 100, top: posY || 24 };

      posX = posX !== null ? posX : rect.left || 100;
      posY = posY !== null ? posY : rect.top || 24;

      if (e.key === "ArrowUp") posY = Math.max(0, posY - step);
      if (e.key === "ArrowDown") posY += step;
      if (e.key === "ArrowLeft") posX = Math.max(0, posX - step);
      if (e.key === "ArrowRight") posX += step;

      overlay.style.left = `${posX}px`;
      overlay.style.top = `${posY}px`;
      overlay.style.right = "auto";
      overlay.style.bottom = "auto";
    }
  }

  window.addEventListener("keydown", handleStealthKeydown);

  function handleContentMessage(message) {
    if (!message || !message.action) return;

    if (message.action === "hide_overlay" || message.action === "Stop Capture") {
      overlay.style.display = "none";
      return;
    }

    if (!isHidden) {
      overlay.style.display = "flex";
    }

    if (message.action === "Update Live Transcript") {
      const transcriptEl = document.getElementById("ma-transcript-text");
      if (transcriptEl) {
        transcriptEl.textContent = message.text;
        transcriptEl.style.opacity = message.isFinal ? "1" : "0.78";
      }
    }

    if (message.action === "Update AI Coach") {
      const coachEl = document.getElementById("ma-coach-text");
      if (coachEl) {
        coachEl.textContent = message.advice;
        coachEl.style.color = "#ff4d4d";
      }
    }

    if (message.action === "Stream AI Coach") {
      const coachEl = document.getElementById("ma-coach-text");
      if (coachEl) {
        coachEl.textContent = message.text;
        coachEl.style.color = "#ff4d4d";
      }
    }

    if (message.action === "Update Engine Status") {
      const statusEl = document.getElementById("ma-status-label");
      if (statusEl && message.status) {
        statusEl.textContent = `● ${message.status}`;
      }
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleContentMessage(message);
    if (sendResponse) sendResponse({ ok: true });
    return false;
  });

  if (typeof module !== "undefined" && module.exports) {
    module.exports = {
      createOverlayElement,
      handleContentMessage,
      handleStealthKeydown,
      _getOverlayState: () => ({ isClickThrough, isHidden, posX, posY, overlay })
    };
  }
})();
