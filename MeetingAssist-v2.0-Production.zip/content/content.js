// =========================================================
// 4. CONTENT SCRIPT (Cheating Daddy Stealth Overlay + Shortcuts)
// =========================================================

(function initMeetingAssistOverlay() {
  if (window.MEETING_ASSIST_OVERLAY_INJECTED) {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) {
      existing.style.display = "flex";
    }
    if (typeof window._meetingAssistResetVisibility === "function") {
      window._meetingAssistResetVisibility();
    }
    return;
  }
  window.MEETING_ASSIST_OVERLAY_INJECTED = true;

  let isClickThrough = false;
  let isHidden = false;
  let posX = null;
  let posY = null;

  // Global helper to restore HUD visibility when re-launched from popup
  window._meetingAssistResetVisibility = function () {
    isHidden = false;
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) existing.style.display = "flex";
  };

  const PLACEHOLDER_TEXTS = [
    "listening for interviewer question...",
    "listening for question or dialogue...",
    "listening for interviewer...",
    "listening for",
    "answers and code solutions will appear here"
  ];

  function getActiveTranscriptPrompt() {
    const transcriptEl = document.getElementById("ma-transcript-text");
    const rawText = (transcriptEl && transcriptEl.textContent.trim()) || "";
    const isPlaceholder = !rawText || PLACEHOLDER_TEXTS.some((p) => rawText.toLowerCase().includes(p));
    if (isPlaceholder) {
      return "Analyze the current screen and solve the coding problem or question visible.";
    }
    return rawText;
  }

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // v3.1 Structured Response Cards (Carbon & Amber Styling)
  function renderStructuredCards(rawText) {
    if (!rawText) return "";
    const trimmed = rawText.trim();
    if (trimmed.startsWith("⚡") || trimmed.startsWith("📸") || trimmed.startsWith("[Coach")) {
      return `<div style="color: #fbbf24; font-weight: 700; padding: 4px 0; font-size: 12px;">${escapeHtml(trimmed)}</div>`;
    }

    const lines = trimmed.split("\n").map((l) => l.trim()).filter(Boolean);
    let html = "";
    let codeBlock = false;
    let codeContent = "";

    lines.forEach((line) => {
      if (line.startsWith("```")) {
        if (!codeBlock) {
          codeBlock = true;
          codeContent = "";
        } else {
          codeBlock = false;
          html += `
            <div style="background: rgba(0,0,0,0.55); border: 1px solid rgba(245,158,11,0.25); border-radius: 6px; padding: 8px 10px; margin: 6px 0; font-family: monospace; font-size: 11px; color: #7dd3fc; overflow-x: auto;">
              <div style="font-size: 9px; color: #fbbf24; text-transform: uppercase; margin-bottom: 3px; font-weight: 800; letter-spacing: 0.05em;">Code / Algorithm</div>
              <code>${escapeHtml(codeContent.trim())}</code>
            </div>`;
        }
        return;
      }

      if (codeBlock) {
        codeContent += line + "\n";
        return;
      }

      const cleanLine = line.replace(/^[\\*\\-\\•\\d\\.]+\\s*/, "").trim();
      if (!cleanLine) return;

      // Structured Card with Signal Amber Left Accent
      html += `
        <div style="
          background: rgba(245, 158, 11, 0.08);
          border-left: 3px solid #f59e0b;
          border-radius: 4px;
          padding: 6px 10px;
          margin-bottom: 6px;
          color: #fef3c7;
          font-size: 12.5px;
          line-height: 1.45;
          font-weight: 500;
        ">
          ${escapeHtml(cleanLine)}
        </div>`;
    });

    return html || `<div style="color: #fef3c7; font-size: 12.5px;">${escapeHtml(trimmed)}</div>`;
  }

  function createOverlayElement() {
    const existing = document.getElementById("meeting-assist-overlay");
    if (existing) return existing;

    const container = document.createElement("div");
    container.id = "meeting-assist-overlay";
    Object.assign(container.style, {
      position: "fixed",
      top: "24px",
      right: "24px",
      width: "420px",
      minHeight: "260px",
      background: "linear-gradient(155deg, rgba(18, 22, 34, 0.96) 0%, rgba(10, 13, 20, 0.98) 100%)",
      color: "#f8fafc",
      borderRadius: "12px",
      border: "1px solid rgba(245, 158, 11, 0.35)",
      boxShadow: "0 20px 50px rgba(0, 0, 0, 0.8), 0 0 25px rgba(245, 158, 11, 0.12)",
      zIndex: "2147483647",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      backdropFilter: "blur(14px)",
      transition: "opacity 0.15s ease"
    });

    // Inject CSS for Live Equalizer and Carbon Styling
    if (!document.getElementById("ma-equalizer-styles")) {
      const style = document.createElement("style");
      style.id = "ma-equalizer-styles";
      style.textContent = `
        @keyframes ma-eq-pulse-1 { 0%, 100% { height: 3px; } 50% { height: 11px; } }
        @keyframes ma-eq-pulse-2 { 0%, 100% { height: 8px; } 50% { height: 3px; } }
        @keyframes ma-eq-pulse-3 { 0%, 100% { height: 4px; } 50% { height: 12px; } }
        @keyframes ma-eq-pulse-4 { 0%, 100% { height: 10px; } 50% { height: 5px; } }
        .ma-eq-active .eq-1 { animation: ma-eq-pulse-1 0.65s infinite ease-in-out; }
        .ma-eq-active .eq-2 { animation: ma-eq-pulse-2 0.5s infinite ease-in-out 0.12s; }
        .ma-eq-active .eq-3 { animation: ma-eq-pulse-3 0.75s infinite ease-in-out 0.25s; }
        .ma-eq-active .eq-4 { animation: ma-eq-pulse-4 0.55s infinite ease-in-out 0.38s; }
      `;
      document.head.appendChild(style);
    }

    container.innerHTML = `
      <!-- CARBON & AMBER INDUSTRIAL HEADER -->
      <div id="ma-header" style="
        padding: 8px 12px;
        background: rgba(245, 158, 11, 0.05);
        border-bottom: 1px solid rgba(245, 158, 11, 0.2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: move;
        user-select: none;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.03em;
        color: #fbbf24;
      ">
        <div style="display: flex; align-items: center; gap: 7px;">
          <!-- LIVE AUDIO EQUALIZER -->
          <div id="ma-equalizer" class="ma-eq-active" title="Live audio stream active" style="
            display: flex;
            align-items: flex-end;
            gap: 2.5px;
            height: 12px;
            padding-bottom: 1px;
          ">
            <span class="eq-1" style="width: 2.5px; height: 5px; background: #f59e0b; border-radius: 1px;"></span>
            <span class="eq-2" style="width: 2.5px; height: 9px; background: #fbbf24; border-radius: 1px;"></span>
            <span class="eq-3" style="width: 2.5px; height: 4px; background: #f59e0b; border-radius: 1px;"></span>
            <span class="eq-4" style="width: 2.5px; height: 11px; background: #fbbf24; border-radius: 1px;"></span>
          </div>
          <span id="ma-status-label" style="color: #fbbf24; font-weight: 800; font-size: 10.5px; letter-spacing: 0.04em;">
            CARBON & AMBER HUD · LIVE
          </span>
        </div>

        <div style="display: flex; align-items: center; gap: 6px;">
          <button id="ma-answer-now-btn" title="Instantly analyze current transcript (⚡)" style="
            background: rgba(245, 158, 11, 0.2);
            border: 1px solid rgba(245, 158, 11, 0.5);
            color: #fde68a;
            cursor: pointer;
            font-size: 10px;
            font-weight: 700;
            line-height: 1;
            padding: 3px 8px;
            border-radius: 4px;
            letter-spacing: 0.02em;
            transition: background 0.15s ease;
          ">⚡ Answer</button>
          <button id="ma-vision-btn" title="Snap current screen & solve visible problem (📸)" style="
            background: rgba(56, 189, 248, 0.18);
            border: 1px solid rgba(56, 189, 248, 0.45);
            color: #7dd3fc;
            cursor: pointer;
            font-size: 10px;
            font-weight: 700;
            line-height: 1;
            padding: 3px 8px;
            border-radius: 4px;
            letter-spacing: 0.02em;
          ">📸 Vision</button>
          <span id="ma-mode-pill" style="
            font-size: 9.5px;
            padding: 2px 6px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.08);
            color: #cbd5e1;
          ">Ctrl+M</span>
          <button id="ma-close-btn" title="Hide (Ctrl+\\)" style="
            background: transparent;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 14px;
            line-height: 1;
            padding: 0 4px;
          ">×</button>
        </div>
      </div>

      <!-- TOP HALF: LIVE INTERVIEWER TRANSCRIPT -->
      <div id="ma-top-half" style="
        padding: 10px 14px;
        background: rgba(0, 0, 0, 0.25);
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        min-height: 70px;
        max-height: 105px;
        overflow-y: auto;
      ">
        <div style="font-size: 9.5px; text-transform: uppercase; letter-spacing: 0.07em; color: #78716c; margin-bottom: 4px; font-weight: 700;">
          Interviewer / Live Audio Feed
        </div>
        <div id="ma-transcript-text" style="font-size: 12.5px; line-height: 1.45; color: #f1f5f9;">
          Listening for interviewer question...
        </div>
      </div>

      <!-- BOTTOM HALF: STRUCTURED TACTICAL RESPONSE CARDS -->
      <div id="ma-bottom-half" style="
        flex: 1;
        padding: 12px 14px;
        background: rgba(245, 158, 11, 0.03);
        min-height: 115px;
        max-height: 230px;
        overflow-y: auto;
      ">
        <div style="font-size: 9.5px; text-transform: uppercase; letter-spacing: 0.07em; color: #fbbf24; margin-bottom: 6px; font-weight: 800;">
          Tactical Copilot (Llama 3.3 70B & Gemini)
        </div>
        <div id="ma-coach-text" style="font-size: 12.5px; line-height: 1.48; color: #fde68a;">
          <div style="background: rgba(245, 158, 11, 0.07); border-left: 3px solid #f59e0b; border-radius: 4px; padding: 7px 10px; color: #fde68a; font-size: 12px;">
            Answers and code solutions will stream here in structured tactical cards.
          </div>
        </div>
      </div>

      <!-- CARBON QUICK PROMPT FOOTER -->
      <div id="ma-footer" style="
        padding: 7px 10px;
        background: rgba(10, 13, 20, 0.85);
        border-top: 1px solid rgba(255, 255, 255, 0.08);
        display: flex;
        gap: 6px;
      ">
        <input id="ma-manual-input" type="text" placeholder="Type question or press Enter to solve screen..." style="
          flex: 1;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(245, 158, 11, 0.25);
          border-radius: 6px;
          color: #f8fafc;
          font-size: 11.5px;
          padding: 6px 9px;
          outline: none;
        " />
      </div>
    `;

    document.body.appendChild(container);

    const closeBtn = container.querySelector("#ma-close-btn");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        isHidden = true;
        container.style.display = "none";
      });
    }

    // ⚡ Answer button — fires coach call with placeholder guard
    const answerNowBtn = container.querySelector("#ma-answer-now-btn");
    if (answerNowBtn) {
      answerNowBtn.addEventListener("click", (e) => {
        e.stopPropagation(); // don't trigger drag
        const promptText = getActiveTranscriptPrompt();
        const coachEl = document.getElementById("ma-coach-text");
        if (coachEl) coachEl.textContent = "⚡ Analyzing...";
        chrome.runtime.sendMessage({ action: "Manual Prompt", promptText });
      });
    }

    // 📸 Vision button — snaps screen & solves visible problem with placeholder guard
    const visionBtn = container.querySelector("#ma-vision-btn");
    if (visionBtn) {
      visionBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const promptText = getActiveTranscriptPrompt();
        const coachEl = document.getElementById("ma-coach-text");
        if (coachEl) coachEl.textContent = "📸 Snapping screen & analyzing...";
        chrome.runtime.sendMessage({ action: "Manual Prompt", promptText });
      });
    }

    const manualInput = container.querySelector("#ma-manual-input");
    if (manualInput) {
      manualInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          const promptText = manualInput.value.trim() || getActiveTranscriptPrompt();
          manualInput.value = "";
          const coachEl = document.getElementById("ma-coach-text");
          if (coachEl) {
            coachEl.textContent = "Analyzing screen + audio context...";
          }
          chrome.runtime.sendMessage({
            action: "Manual Prompt",
            promptText
          });
        }
      });
    }

    // Mouse Dragging Support
    const header = container.querySelector("#ma-header");
    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    if (header) {
      header.addEventListener("mousedown", (e) => {
        if (isClickThrough) return;
        isDragging = true;
        const rect = container.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
      });

      window.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        posX = e.clientX - offsetX;
        posY = e.clientY - offsetY;
        container.style.left = `${posX}px`;
        container.style.top = `${posY}px`;
        container.style.right = "auto";
        container.style.bottom = "auto";
      });

      window.addEventListener("mouseup", () => {
        isDragging = false;
      });
    }

    return container;
  }

  const overlay = createOverlayElement();

  // Cheating Daddy Keyboard Shortcuts:
  // 1. Ctrl/Cmd + M -> Toggle Click-Through Mode (pointer-events: none)
  // 2. Ctrl/Cmd + \ -> Toggle Visibility (Stealth Hide/Show)
  // 3. Ctrl/Cmd + Arrow Keys -> Move Overlay Window by 40px increments
  function handleStealthKeydown(e) {
    const isMod = e.ctrlKey || e.metaKey;
    if (!isMod) return;

    if (e.key.toLowerCase() === "m") {
      e.preventDefault();
      isClickThrough = !isClickThrough;
      overlay.style.pointerEvents = isClickThrough ? "none" : "auto";
      overlay.style.opacity = isClickThrough ? "0.55" : "1";
      const pill = document.getElementById("ma-mode-pill");
      if (pill) {
        pill.textContent = isClickThrough ? "Ctrl+M: Click-Through ON" : "Ctrl+M: Interactive";
      }
      return;
    }

    if (e.key === "\\") {
      e.preventDefault();
      isHidden = !isHidden;
      overlay.style.display = isHidden ? "none" : "flex";
      return;
    }

    const step = 40;
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
      e.preventDefault();
      const rect = overlay.getBoundingClientRect
        ? overlay.getBoundingClientRect()
        : { left: posX || 100, top: posY || 24 };

      posX = posX !== null ? posX : rect.left || 100;
      posY = posY !== null ? posY : rect.top || 24;

      if (e.key === "ArrowUp") posY = Math.max(0, posY - step);
      if (e.key === "ArrowDown") posY += step;
      if (e.key === "ArrowLeft") posX = Math.max(0, posX - step);
      if (e.key === "ArrowRight") posX += step;

      overlay.style.left = `${posX}px`;
      overlay.style.top = `${posY}px`;
      overlay.style.right = "auto";
      overlay.style.bottom = "auto";
    }
  }

  window.addEventListener("keydown", handleStealthKeydown);

  function handleContentMessage(message) {
    if (!message || !message.action) return;

    if (message.action === "show_overlay" || message.action === "restore_overlay") {
      isHidden = false;
      overlay.style.display = "flex";
      return;
    }

    if (message.action === "hide_overlay" || message.action === "Stop Capture") {
      overlay.style.display = "none";
      return;
    }

    if (!isHidden) {
      overlay.style.display = "flex";
    }

    if (message.action === "Update Live Transcript") {
      const transcriptEl = document.getElementById("ma-transcript-text");
      if (transcriptEl) {
        transcriptEl.textContent = message.text;
        transcriptEl.style.opacity = message.isFinal ? "1" : "0.78";
      }
    }

    if (message.action === "Update AI Coach") {
      const coachEl = document.getElementById("ma-coach-text");
      if (coachEl) {
        coachEl.innerHTML = renderStructuredCards(message.advice);
      }
    }

    if (message.action === "Stream AI Coach") {
      const coachEl = document.getElementById("ma-coach-text");
      if (coachEl) {
        coachEl.innerHTML = renderStructuredCards(message.text);
      }
    }

    if (message.action === "Update Engine Status") {
      const statusEl = document.getElementById("ma-status-label");
      if (statusEl && message.status) {
        statusEl.textContent = `● ${message.status}`;
      }
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleContentMessage(message);
    if (sendResponse) sendResponse({ ok: true });
    return false;
  });

  if (typeof module !== "undefined" && module.exports) {
    module.exports = {
      createOverlayElement,
      handleContentMessage,
      handleStealthKeydown,
      _getOverlayState: () => ({ isClickThrough, isHidden, posX, posY, overlay })
    };
  }
})();
